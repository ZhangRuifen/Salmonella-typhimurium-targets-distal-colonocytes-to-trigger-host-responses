
CCA<-readRDS("G:/colon.rds")
head(CCA@meta.data)
DimPlot(CCA,group.by = "subCellType",label=TRUE)


####################### 0.UMAP图 ####################### 

custom_colors<-c(
  "Enterocytes1" = "#A6CEE3",      # 低饱和度蓝色
  "Enterocytes2" = "#B2DF8A",           # 低饱和度绿色
  "Mature_colonocyte2" = "#FB9A99",      # 低饱和度红色
  "Stem2" = "#FBB4AE",               # 低饱和度粉色
  "BEST_enterocytes" = "#B3B3CC",             # 低饱和度灰蓝色
  "Mature_colonocyte1" = "#CCEBC5",     # 低饱和度绿色
  "Mature_colonocyte3" = "#F7C8A5",      # 低饱和度橙色
  "Stem1" = "#E6F5D0",         # 低饱和度草绿色
  "Goblet" = "#A6D7D0",               # 低饱和度浅蓝色
  "Tuft" = "#E5D8BD"              # 低饱和度米色
)
custom_colors_deep <- c(
  "Enterocytes1" = "#1F77B4",       # 深蓝色
  "Enterocytes2" = "#33A02C",            # 深绿色
  "Mature_colonocyte2" = "#E31A1C",       # 深红色
  "Stem2" = "#D9346F",                # 深粉色
  "BEST_enterocytes" = "#6A6ACC",              # 深灰蓝色
  "Mature_colonocyte1" = "#5ABD7A",     # 深绿色
  "Mature_colonocyte3" = "#E68A55",      # 深橙色
  "Stem1" = "#7FBF7B",         # 深草绿色
  "Goblet" = "#33827D",                # 深浅蓝色
  "Tuft" = "#B3A485"              # 深米色
)


unique(har_CTRL@meta.data$CellType)

col<-c("#FDBF6F","#FF7F00","#FB9A99" ,"#1F78B4","#33A02C",
       "#B2DF8A", "#76D7C4","#A6CEE3" ,"#E31A1C","#e9bc00")

p<-DimPlot(CCA,group.by = "subCellType",cols = col)
ggsave(plot = p,filename = "G://p.pdf",units = "mm",width = 160,height = 130)

####################### 1.Addmodulescore打分图 ####################### 
CCA<-AddModuleScore(object = CCA,features = marker_DCC,name = "DCC_like")

mydata<-FetchData(CCA,vars = c("umap_1","umap_2","DCC_like1"))

p_DCC<-ggplot(mydata,aes(x = umap_1 , y = umap_2, colour = DCC_like1))+
  geom_point(size=1)+
  scale_color_gradientn(values = seq(0,1,0.2), colours = c("#b3dee2","#eaf2d7","#efcfe3","#ea9ab2","#e27396"))+
  theme(
    panel.background = element_rect(fill = "white"),
    panel.border = element_blank(), # 去掉绘图区域的边框
    panel.grid.major = element_blank(), # 去掉主要网格线
    panel.grid.minor =  element_blank(), # 去掉次要网格线
    axis.line = element_line(colour = "black"))

ggsave(plot = p_DCC,filename = "./Addmodule.pdf",unit='mm',width = 160,height = 150)


####################### 2.绘制箱线图 ####################### 

col<-c("#FDBF6F","#FF7F00","#FB9A99" ,"#1F78B4","#33A02C",
       "#B2DF8A", "#76D7C4","#A6CEE3" ,"#E31A1C","#e9bc00")

meta<-CCA@meta.data
data<-meta[,c(33,35)]
colnames(data)<-c("CellType","DCC_like")
write.csv(data,file = "./DCC.Features.csv")
data<-read.csv("G://DCC.Features.csv")

# 设置特定顺序
data$CellType <- factor(data$CellType, levels = c("BEST_enterocytes","Enterocytes1","Enterocytes2","Goblet",
                                                  "Mature_colonocyte1","Mature_colonocyte2","Mature_colonocyte3",
                                                  "Stem1","Stem2","Tuft"))
library(ggpubr)

# 按照中位数设置因子水平并绘图

unique(CCA@meta.data$subCellType)
cell_colors_border_light <- c(
  "Enterocytes1" = "#FFBC7F",       # 对应 "#FF7F00" 的浅色
  "Enterocytes2" = "#FED2D1",       # 对应 "#FB9A99" 的浅色
  "Mature_colonocyte2" = "#DFF6C7", # 对应 "#B2DF8A" 的浅色
  "Stem2" = "#FF7F7F",               # 对应原代码可能有误，猜测你是想延续风格，这里假设对应类似橙色系 "#FDBF6F" 的浅色
  "BEST_enterocytes" = "#FFE3C7",  # 对应 "#E31A1C" 的浅色
  "Mature_colonocyte1" = "#7BC773", # 对应 "#33A02C" 的浅色
  "Mature_colonocyte3" = "#AFF1E8", # 对应 "#76D7C4" 的浅色
  "Stem1" = "#D3EFFF",              # 对应 "#A6CEE3" 的浅色
  "Goblet" = "#73A6FF",             # 对应 "#1F78B4" 的浅色
  "Tuft" = "#FFF176"                # 对应 "#e9bc00" 的浅色
)
cell_colors_border <- c(
  "Enterocytes1" = "#FF7F00",       # 深蓝色
  "Enterocytes2" = "#FB9A99",            # 深绿色
  "Mature_colonocyte2" = "#B2DF8A",       # 深红色
  "Stem2" = "#E31A1C" ,              # 深粉色
  "BEST_enterocytes" = "#FDBF6F",             # 深灰蓝色
  "Mature_colonocyte1" = "#33A02C",     # 深绿色
  "Mature_colonocyte3" = "#76D7C4",      # 深橙色
  "Stem1" = "#A6CEE3",         # 深草绿色
  "Goblet" = "#1F78B4",                # 深浅蓝色
  "Tuft" = "#e9bc00"              # 深米色
)

levels <- names(sort(tapply(data$DCC_like, data$CellType, median), decreasing = TRUE))
data$CellType <- factor(data$CellType, levels = levels)

p<-ggplot(data, aes(x = CellType, y = DCC_like, fill = CellType, color = CellType)) +
  geom_boxplot(outlier.shape = NA) +  # 不显示离群点
  scale_fill_manual(values = cell_colors_border_light) +  # 自定义填充颜色
  scale_color_manual(values = cell_colors_border) +  # 自定义边框颜色
  theme_minimal() +
  theme(
    legend.position = "none",  # 隐藏图例
    plot.title = element_text(size = 11, face = "bold", hjust = 0.5),  # 标题格式
    axis.text.x = element_text(angle = 45, hjust = 1),  # x轴标签倾斜
    panel.grid.major = element_line(color = "gray90"),  # 主网格线颜色
    panel.grid.minor = element_blank(),  # 去掉次网格线
    axis.line = element_line(color = "black", size = 0.5)
  ) +
  ggtitle("DCC_Features") +
  xlab("") +  # x轴无标签
  ylab("Feature Value") +  # 设置 y 轴标签
  stat_compare_means(
    method = "wilcox.test",  # 使用 Wilcoxon 检验
    label = "p.signif",  # 显示显著性符号:"p.signif"; 使用具体数值："p.format"
    #comparisons = comparisons,  # 每组与 DCC 比较
    hide.ns = TRUE  # 隐藏非显著结果
  )
p

####################### 3.功能富集 ####################### 
library(clusterProfiler)
library(org.Hs.eg.db)

Idents(CCA)<-CCA$subCellType
marker<-FindAllMarkers(CCA,only.pos = TRUE,logfc.threshold = 0.25)


splited<-marker %>%
  group_by(cluster) %>%
  dplyr::filter(avg_log2FC > 1 & p_val_adj<0.05)
splited_cluster<-split(splited,splited$cluster)

go_results <- lapply(splited_cluster, function(df) {
  # 假设每个数据框的基因列名是 'gene_id'
  gene_ids <- df$gene
  
  # 进行GO富集分析
  enrich_result <- enrichGO(
    gene = gene_ids,
    OrgDb = org.Hs.eg.db,   # 根据你的物种选择正确的数据库
    keyType = "SYMBOL",      # 根据你的基因ID类型选择
    ont = "ALL",              # 选择GO分类（BP, MF, CC）
    readable = TRUE     # 设置显著性阈值
  )
  return(enrich_result)
})

lapply(names(go_results), function(name) {
  # 提取当前GO富集结果
  go_data <- as.data.frame(go_results[[name]])
  
  # 构建文件名，使用列表项的名称作为文件名
  file_name <- paste0(name, "_go_results.csv")
  
  # 将结果保存为CSV文件
  write.csv(go_data, file = file_name, row.names = FALSE)
})

all<-list.files()
fp <- paste('G://draw',all,sep = '/')

data_list <- list()
for(i in 1:length(fp)){
  data<-read.csv(file = fp[i],sep = ',', fill = TRUE)
  data<-data[1:3,]
  # 计算qvalue,GeneRatio
  data$'-log(p.adjust)'<- -log10(data$p.adjust)
  strr<-strsplit(as.character(data$GeneRatio),'/') # 变为字符串
  data$GeneRatio<-sapply(strr, function(x) as.numeric(x[1])/as.numeric(x[2]))
  data_list[[i]]<- data
}

new_col_names <- c("BEST_enterocytes","Enterocytes1","Enterocytes2","Goblet",
                   "Mature_colonocyte1","Mature_colonocyte2","Mature_colonocyte3","Stem1","Stem2","Tuft")
list<- list()
for (i in 1:length(fp)) {
  data<-data_list[[i]]
  data$celltype<- new_col_names[i]
  list[[i]]<-data
}
# 合并所有list
listed<-do.call(rbind,list)
listed<-na.omit(listed)
str(listed$celltype)
listed$celltype <- as.factor(listed$celltype)
library(forcats)
listed$celltype <- fct_relevel(listed$celltype, "Stem1","Stem2","Enterocytes1","Enterocytes2","BEST_enterocytes","Mature_colonocyte1",
                               "Mature_colonocyte2","Mature_colonocyte3",
                               "Goblet","Tuft")
levels(listed$celltype)
listed <- listed %>% arrange(celltype)  # 按照因子级别排序整个表格
# 绘图
listed$Description <- as.factor(listed$Description) #设置为因子，顺序不变
listed$Description <- fct_inorder(listed$Description) #按数据出现顺序设置因子级别

title='CellType'
p<-ggplot(listed, aes(celltype, Description)) +
  geom_point(aes(color= -log(p.adjust), size=GeneRatio))+theme_bw()+
  theme(panel.grid = element_blank(),
        axis.text.x=element_text(angle=45,hjust = 1,vjust=1))+
  scale_color_gradient(low="#A6CEE3",high="#FF7F00")+
  labs(x=NULL,y=NULL)+guides(size=guide_legend(order=1))+ggtitle(title)
p

ggsave(plot = p,filename = "G:/scRNAseq相关/Figure/Steven返回意见/250215/public dataset-GG/out/Fig6D.GO.ctrl.pdf",units = 'mm',width = 150,height = 150)
getwd()

####################### 4.关键基因绘制小提琴图 ####################### 
library(ggplot2)
library(ggpubr)
dim(CCA)  # 36390 38555

# 1.提取数据
data<-CCA@assays$RNA$data
data<-as.data.frame(data)
genes<-c("ZBP1", "GBP1", "GBP2","OAS1","OAS3", "GBP3","IRF7", "IRF9", "ISG15", "TRIM15","TRIM31","OASL","LBP")
data_se<-data[genes,]
data_se<-t(data_se)%>%as.data.frame()

### 循环绘制小提琴图
gene_columns <- colnames(all)[2:14]
output_path <- "G://vlnplot/"

meta<-CCA@meta.data
colnames(meta)
meta<-meta[,c(33:35)]

all<-cbind(meta,data_se)
colnames(all)
all<-all[,-c(2,3)]
setwd("G://out")
write.csv(all,file = "./vln.csv")

cell_colors_border_light <- c(
  "Enterocytes1" = "#FFBC7F",       # 对应 "#FF7F00" 的浅色
  "Enterocytes2" = "#FED2D1",       # 对应 "#FB9A99" 的浅色
  "Mature_colonocyte2" = "#DFF6C7", # 对应 "#B2DF8A" 的浅色
  "Stem2" = "#FF7F7F",               # 对应原代码可能有误，猜测你是想延续风格，这里假设对应类似橙色系 "#FDBF6F" 的浅色
  "BEST_enterocytes" = "#FFE3C7",  # 对应 "#E31A1C" 的浅色
  "Mature_colonocyte1" = "#7BC773", # 对应 "#33A02C" 的浅色
  "Mature_colonocyte3" = "#AFF1E8", # 对应 "#76D7C4" 的浅色
  "Stem1" = "#D3EFFF",              # 对应 "#A6CEE3" 的浅色
  "Goblet" = "#73A6FF",             # 对应 "#1F78B4" 的浅色
  "Tuft" = "#FFF176"                # 对应 "#e9bc00" 的浅色
)
cell_colors_border <- c(
  "Enterocytes1" = "#FF7F00",       # 深蓝色
  "Enterocytes2" = "#FB9A99",            # 深绿色
  "Mature_colonocyte2" = "#B2DF8A",       # 深红色
  "Stem2" = "#E31A1C" ,              # 深粉色
  "BEST_enterocytes" = "#FDBF6F",             # 深灰蓝色
  "Mature_colonocyte1" = "#33A02C",     # 深绿色
  "Mature_colonocyte3" = "#76D7C4",      # 深橙色
  "Stem1" = "#A6CEE3",         # 深草绿色
  "Goblet" = "#1F78B4",                # 深浅蓝色
  "Tuft" = "#e9bc00"              # 深米色
)

# 设置特定的celltype顺序
all$subCellType <- factor(all$subCellType, levels = c("Mature_colonocyte2", "BEST_enterocytes","Mature_colonocyte1",
                                                      "Mature_colonocyte3", "Enterocytes2","Goblet","Tuft",
                                                      "Enterocytes1","Stem2","Stem1"  ))

genes<-c("ZBP1", "GBP1", "GBP2","OAS1","OAS3", "GBP3","IRF7", "IRF9", "ISG15", "TRIM15","TRIM31","OASL")

# 内
color_in<-c( "#DFF6C7","#FFE3C7", "#7BC773", "#AFF1E8","#FED2D1","#73A6FF", "#FFF176","#FFBC7F","#FF7F7F","#D3EFFF")
# 外
color<-c( "#B2DF8A","#FDBF6F","#33A02C", "#76D7C4", "#FB9A99","#1F78B4", "#e9bc00","#FF7F00","#E31A1C","#A6CEE3")

summary(all)
for (gene in gene_columns) {
  # 绘制小提琴图
  p <- ggplot(all, aes(x = subCellType, y = get(gene), fill = subCellType)) +
    geom_violin(scale = "width", width = 0.8, adjust = 10) +  # 通过增加adjust值，使得图形变胖
    scale_fill_manual(values = color_in) +  # 设置小提琴的填充颜色
    geom_jitter(aes(color = subCellType), alpha = 0.4, shape = 16, size = 1, position = position_jitter(0.3)) + 
    scale_color_manual(values = color) +  # 设置数据点的颜色
    stat_summary(fun = "mean", geom = "crossbar",  # 均值mean
                 width = 0.5, color = "#495057", size = 0.5) +  
    # #geom_signif(comparisons = comparisons, 
    #             map_signif_level = TRUE, 
    #             textsize = 3, 
    #             test = t.test, 
    #             step_increase = 0.2) +
    guides(fill = F) + 
    xlab(NULL) +
    ggtitle(gene)+
    theme_classic() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
  
  output_file <- paste0(output_path, gene, ".pdf")
  ggsave(output_file, plot = p, width = 5, height = 4)
}


