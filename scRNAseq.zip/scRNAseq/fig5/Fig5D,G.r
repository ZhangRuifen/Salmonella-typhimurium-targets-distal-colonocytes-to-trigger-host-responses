
all<-list.files()
fp <- paste('G://table',all,sep = '/')

data_list <- list()
for(i in 1:length(fp)){
  data<-read.csv(file = fp[i],sep = ',', fill = TRUE)
  data<-data[data$ONTOLOGY=="BP",]
  data_list[[i]]<- data
}
names<-c('Imflamed_Healthy','Uninflamed_Healthy','d1_d0','d3_d0','d5_d0','d7_d0')

list<- list()
for (i in 1:length(fp)) {
  data<-data_list[[i]]
  data$celltype<- names[i]
  list[[i]]<-data
}


# UC组
UC.list<-list[c(1,2)]
STM.list<-list[c(3,4,5,6)]

SE.list<-list[c(1,3,4,5)] 

# 提取每个 GO 结果的 Description 列
descriptions_list <- lapply(SE.list, function(x) x$Description)
# 找到所有 GO 结果中 Description 列的交集
common_descriptions <- Reduce(intersect, descriptions_list)



# 合并所有list
listed<-do.call(rbind,list)
listed<-na.omit(listed)
str(listed$celltype)
listed$celltype <- as.factor(listed$celltype)
listed$celltype <- fct_relevel(listed$celltype, "Mature_colonocyte0","Mature_colonocyte1","Epithelial_stem","Epithelial_cycling",
                               "Enterocyte","BEST4_enterocyte_colonocyte","Goblet",
                               "Enteroendocrine", "Tuft")
levels(listed$celltype)
listed <- listed %>%
  arrange(celltype) 
# 绘图
listed$Description <- as.factor(listed$Description) #设置为因子，顺序不变
listed$Description <- fct_inorder(listed$Description)

listed$Description <- fct_relevel(listed$celltype, order_of_description)

title='CellType'
p<-ggplot(listed, aes(celltype, Description)) +
  geom_point(aes(color= -log(p.adjust), size=GeneRatio))+theme_bw()+
  theme(panel.grid = element_blank(),
        axis.text.x=element_text(angle=45,hjust = 1,vjust=1))+
  scale_color_gradient(low="#A6CEE3",high="#FF7F00")+
  labs(x=NULL,y=NULL)+guides(size=guide_legend(order=1))+ggtitle(title)
p


# UC组
UC.list<-list[c(1,2)]
STM.list<-list[c(3,4,5,6)]

# 1.确定绘图所用分组
SE.list<-list[c(1,3,4,5)] # 将UC组中inflamed组，与d1,3,5提取出来

# 2.提取每个 GO 结果的 Description 列
descriptions_list <- lapply(SE.list, function(x) x$Description)

# 3.找到所有 GO 结果中 Description 列的交集
common_descriptions <- Reduce(intersect, descriptions_list)

# 4.提取交集counts

counts_matrix <- sapply(SE.list, function(go_result) {
  counts <- go_result[go_result$Description %in% common_descriptions, "Count"]
  # 如果有缺失的 counts，填充为 0 或其他值
  return(counts)
})

names<-c('Imflamed_Healthy','Uninflamed_Healthy','d1_d0','d3_d0','d5_d0','d7_d0')
# 给 counts_matrix 行和列添加适当的标签
rownames(counts_matrix) <- common_descriptions
colnames(counts_matrix) <- c('Imflamed_Healthy','d1_d0','d3_d0','d5_d0')

# 安装并加载 pheatmap 包
install.packages("pheatmap")
library(pheatmap)

# 绘制热图
pheatmap(counts_matrix, scale = "row",  # 'none', 'row' or 'column'
         cluster_rows = TRUE,  # 是否对行进行聚类
         cluster_cols = FALSE,  # 是否对列进行聚类
         color = colorRampPalette(c("white", "blue"))(100))  # 设置颜色

