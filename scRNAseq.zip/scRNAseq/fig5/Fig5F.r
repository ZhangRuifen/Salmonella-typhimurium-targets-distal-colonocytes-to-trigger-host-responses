all<-list.files()
fp <- paste('F:/GO',all,sep = '/')

data_list <- list()
for(i in 1:length(fp)){
  data<-read.csv(file = fp[i],sep = ',', fill = TRUE)
  data<-data[1:5,]
  # 计算qvalue,GeneRatio
  data$'-log(p.adjust)'<- -log10(data$p.adjust)
  strr<-strsplit(as.character(data$GeneRatio),'/') # 变为字符串
  data$GeneRatio<-sapply(strr, function(x) as.numeric(x[1])/as.numeric(x[2]))
  data_list[[i]]<- data
}

new_col_names <- c("Best4+ Enterocytes","Cycling TA","Enterocyte Progenitors","Enterocytes",
                   "Enteroendocrine","Goblet","Immature Enterocytes 1","Immature Enterocytes 2",
                   "Immature Goblet","M cells","Secretory TA","Stem","TA 1","TA 2","Tuft")
list<- list()
for (i in 1:length(fp)) {
  data<-data_list[[i]]
  data$celltype<- new_col_names[i]
  list[[i]]<-data
}
# 合并所有list
listed<-do.call(rbind,list)
listed<-na.omit(listed)
str(listed$celltype)
listed$celltype <- as.factor(listed$celltype)
listed$celltype <- fct_relevel(listed$celltype, "Enterocytes","Immature Enterocytes 1","Immature Enterocytes 2",
                               "Enterocyte Progenitors","TA 1","TA 2","Cycling TA","Secretory TA","Immature Goblet",
                               "Goblet","Best4+ Enterocytes",
                               "Enteroendocrine","M cells","Stem","Tuft")
levels(listed$celltype)
listed <- listed %>%
  arrange(celltype) 
# 绘图
listed$Description <- as.factor(listed$Description) 
listed$Description <- fct_inorder(listed$Description)

title='UC-CellType'
p<-ggplot(listed, aes(celltype, Description)) +
  geom_point(aes(color= -log(p.adjust), size=GeneRatio))+theme_bw()+
  theme(panel.grid = element_blank(),
        axis.text.x=element_text(angle=45,hjust = 1,vjust=1))+
  scale_color_gradient(low="#A6CEE3",high="#FF7F00")+
  labs(x=NULL,y=NULL)+guides(size=guide_legend(order=1))+ggtitle(title)


#### DEG  ####
setwd("F://Enterocytes")

all<-list.files()
fp <- paste('F://Enterocytes',all,sep = '/')

data_list <- list()
for(i in 1:length(fp)){
  data<-read.csv(file = fp[i],sep = ',', fill = TRUE)
  data<-data[1:10,]
  # 计算qvalue,GeneRatio
  data$'-log(p.adjust)'<- -log10(data$p.adjust)
  strr<-strsplit(as.character(data$GeneRatio),'/') # 变为字符串
  data$GeneRatio<-sapply(strr, function(x) as.numeric(x[1])/as.numeric(x[2]))
  data_list[[i]]<- data
}

new_col_names <- c("Imflamed_Healthy","Uninflamed_Healthy","Enterocytes")
list<- list()
for (i in 1:length(fp)) {
  data<-data_list[[i]]
  data$celltype<- new_col_names[i]
  list[[i]]<-data
}
listed<-do.call(rbind,list)
listed<-na.omit(listed)
str(listed$celltype)

listed$Description <- as.factor(listed$Description) #设置为因子，顺序不变
listed$Description <- fct_inorder(listed$Description)

title='GO-Enterocytes'
p<-ggplot(listed, aes(celltype, Description)) +
  geom_point(aes(color= -log(p.adjust), size=GeneRatio))+theme_bw()+
  theme(panel.grid = element_blank(),
        axis.text.x=element_text(angle=45,hjust = 1,vjust=1))+
  scale_color_gradient(low="#aed9e0",high="#ffa69e")+
  labs(x=NULL,y=NULL)+guides(size=guide_legend(order=1))+ggtitle(title)
p
ggsave(plot = p,filename = "G://DEG.GO.pdf",units = 'mm',width = 180,height = 150)


