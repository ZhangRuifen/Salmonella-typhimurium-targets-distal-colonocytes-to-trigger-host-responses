
Idents(rename_Epithelial)<-rename_Epithelial$day
d0<-subset(rename_Epithelial,idents=c("day 0"))
DefaultAssay(d0)<-"RNA"

Idents(d0)<-d0$subCelltype

comparisons<-list(c("DCC","Pre_DCC"), c("DCC","Mid_CC"),c("DCC", "PCC"),c("DCC","Pre_PCC"),  c("DCC","Goblet_2"), 
                  c("DCC","Goblet_0"),c("DCC","Goblet_1"),c("DCC","Stem/TA"),
                  c("DCC", "EEC"),c("DCC","M_cell"))
d0$subCelltype <- factor(d0$subCelltype, levels = c(
  "DCC","Pre_DCC","Mid_CC","PCC","Pre_PCC", "Goblet_2","Goblet_0","Goblet_1",     
  "Stem/TA",  "EEC", "M_cell"
))

cell_colors_border <- c("Stem/TA"="#E31A1C","Pre_DCC"="#FF7F00","DCC"="#FDBF6F","Pre_PCC"="#1F78B4","PCC"= "#A6CEE3" ,"Mid_CC"= "#FB9A99",
                        "Goblet_0"="#777e41", "Goblet_1"="#33A02C", "Goblet_2"= "#B2DF8A",
                        "M_cell"="#6A3D9A", "EEC"="#e9bc00")

cell_colors_fill <- c("Stem/TA" = "#D77A7A", 
                      "Pre_DCC" = "#EFA548", 
                      "DCC" = "#F4D39D", 
                      "Pre_PCC" = "#5A8EB5", 
                      "PCC" = "#A9C9D4", 
                      "Mid_CC" = "#F4B0B0", 
                      "Goblet_0" = "#A0A86A", 
                      "Goblet_1" = "#78B675", 
                      "Goblet_2" = "#C4E2B4", 
                      "M_cell" = "#8E77B0", 
                      "EEC" = "#F1D85C")

p<-VlnPlot(d0, features = c('Zbp1','Lbp','Gbp2','Irf7','Isg15','Oas1a',
                            'Oas1g','Oas3','Trim15','Trim30a'), group.by = "subCelltype",ncol = 5)&  
  # 1.使用白底作为背景
  theme_bw()&  
  # 2.主题设置：设置整个图形的文本，边框粗细等
  theme(axis.title.x = element_blank(),  # 移除X轴标题      
        axis.text.x = element_text(color = 'black', size = 10,angle = 45, hjust = 1),  # X轴标签设置，hjust:调整水平位置      
        axis.text.y = element_text(color = 'black'),   # 移除Y轴标题       
        axis.title.y = element_text(color = 'black', size = 12),        
        panel.grid.major = element_blank(),  # 移除主网格线       
        panel.grid.minor = element_blank(),  # 移除次网格线
        panel.border = element_blank(),  # 移除整体边框
        axis.line = element_line(color = "black", linewidth = 0.8),   # 添加X轴和Y轴边框
        panel.spacing = unit(0.12, "cm"), # 调整不同面板的间距        
        plot.title = element_text(hjust = 0.5),  # face = "bold.italic"      
        legend.position = 'none')&   # 移除图例
  # 3.统计检验
  stat_compare_means(method="t.test",hide.ns = F,                      
                     comparisons = comparisons,                     
                     label="p.signif",                     
                     bracket.size=0.6,  # 括号线条宽度                  
                     tip.length= 0.02,  # 括号端点长度 
                     size=4,            # 显著性标记字体大小
                     vjust = 0.2,       # 显著性标记向下移动（负值：向上 正值：向下）
                     step.increase = 0.15  # 调整每组比较括号之间的间隔
                     )& 
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.1)))&  # 上端留空间，下端留空间 
  scale_fill_manual(values = cell_colors_border)


data<-d0@assays$RNA$data
data<-as.data.frame(data)
data_select<-data[c('Zbp1','Lbp','Gbp2','Irf7','Isg15','Oas1a',
                    'Oas1g','Oas3','Trim15','Trim30a'),]
data_select1<-t(data_select)%>% as.data.frame()


meta<-d0@meta.data
colnames(meta)
meta<-meta[,-c(1:12,14,16:24)]

a<-cbind(meta,data_select1)
write.csv(a,file = "vlnplot_data.csv")


