library(ggplot2)
library(ggpubr)
library(forcats)

all<-list.files()
fp <- paste('G://d0',all,sep = '/')

data_list <- list()
for(i in 1:11){
  data<-read.csv(file = fp[i],sep = ',')
  data<-data[1:8,]
  # 计算qvalue,GeneRatio
  data$'-log(p.adjust)'<- -log10(data$p.adjust)
  strr<-strsplit(as.character(data$GeneRatio),'/') # 变为字符串
  data$GeneRatio<-sapply(strr, function(x) as.numeric(x[1])/as.numeric(x[2]))
  data_list[[i]]<- data
}

new_col_names <- c("DCC","EEC","Goblet_0","Goblet_1","Goblet_2","M_cell","Mid_CC","PCC","pre_DCC","pre_PCC", "Stem_TA")
list<- list()
for (i in 1:11) {
  data<-data_list[[i]]
  data$celltype<- new_col_names[i]
  list[[i]]<-data
}

listed<-do.call(rbind,list)
listed<-na.omit(listed)
listed$Description <- as.factor(listed$Description) 
listed$Description <- fct_inorder(listed$Description)
title='d0_CellType'

p<-ggplot(listed, aes(celltype, Description)) +
  geom_point(aes(color = -log(p.adjust), size = GeneRatio)) +
  theme_bw() +
  theme(
    panel.grid = element_blank(),        # 移除网格线
    axis.text = element_blank(),         # 移除所有坐标轴刻度标签
    axis.ticks = element_blank(),        # 移除所有坐标轴刻度
    axis.title = element_blank(),        # 移除所有坐标轴标题
    legend.text = element_blank(),       # 移除图例文本
    legend.title = element_blank(),      # 移除图例标题
    plot.title = element_blank()         # 移除图标题
  ) +
  scale_color_gradient(low = '#9381ff', high = '#ffd8be') +
  #guides(size = "none") +                # 移除图例（如果完全不需要）
  coord_flip()
ggsave(plot = p,filename = "p.pdf",units = 'mm',width = 350,height = 50)
