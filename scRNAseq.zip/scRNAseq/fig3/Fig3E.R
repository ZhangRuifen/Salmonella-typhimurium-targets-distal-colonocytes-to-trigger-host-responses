library(openxlsx)
data <- read.xlsx("Z://data.xlsx")
colnames(data)[1] <- "day"
rownames(data) <- data$day  
data <- data[,-1]  
data <- t(data)
data <- as.data.frame(data)
rownames(data)[rownames(data) == "pre_DCC"] <- "Pre_DCC"
rownames(data)[rownames(data) == "pre_PCC"] <- "Pre_PCC"
new_order <- c("Stem/TA","pre_DCC","pre_PCC","DCC","PCC","Mid_CC","Goblet_0","Goblet_1","Goblet_2",
               "M_cell","EEC")
new_order <- c("DCC","Mid_CC","PCC","M_cell","Goblet_0","Pre_PCC","Stem/TA",
               "Goblet_1","Pre_DCC",
               "EEC","Goblet_2")
df <- data[new_order, ]
setwd("Z:/")
p <-pheatmap(df,
         cluster_rows = FALSE,
         cluster_cols = FALSE,
         show_rownames = TRUE,
         show_colnames = TRUE,
         main = "Map of differentiation rates of differnent cell types",
         color = colorRampPalette(c("#0033FF", "white","#FF0000"))(100)   
)




