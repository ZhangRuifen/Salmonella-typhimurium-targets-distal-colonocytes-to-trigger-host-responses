library(Seurat)
library(Matrix)
library(tidyverse)
library(patchwork)
library(sctransform)
library(reticulate)
library(clustree)
theme_set(theme_bw())

### INGEST RAW DATA AND DOUBLET PREDICTIONS

A8<-readRDS('/A8/R_SCT/A8.rds')
A11<-readRDS('/A11/R_SCT/A11.rds')
A17<-readRDS('/A17/R_SCT/A17.rds')
A27<-readRDS('/A27/R_SCT/A27.rds')
A23<-readRDS('/A23/R_SCT/A23.rds')
A29<-readRDS('/A29/R_SCT/A29.rds')
A19<-readRDS('/A19/R_SCT/A19.rds')
d5_2<-readRDS('/D5_2/R_SCT/D5_2.rds')
A4<-readRDS('/A4/R_SCT/A4.rds')
A6<-readRDS('/A6/R_SCT/A6.rds')

### doublet predictions ###

doublets.A8<-read.table('/A8/DoubletFinder/DoubletFinder_doublets_singlets.txt',sep='\t',header=T)
singlets.A8<-subset(doublets.A8,doublets.A8$DoubletFinder_DropletType == 'singlet')
doublets.A11<-read.table('/A11/DoubletFinder/DoubletFinder_doublets_singlets.txt',sep='\t',header=T)
singlets.A11<-subset(doublets.A11,doublets.A11$DoubletFinder_DropletType == 'singlet')
doublets.A17<-read.table('/A17/DoubletFinder/DoubletFinder_doublets_singlets.txt',sep='\t',header=T)
singlets.A17<-subset(doublets.A17,doublets.A17$DoubletFinder_DropletType == 'singlet')
doublets.A27<-read.table('/A27/DoubletFinder/DoubletFinder_doublets_singlets.txt',sep='\t',header=T)
singlets.A27<-subset(doublets.A27,doublets.A27$DoubletFinder_DropletType == 'singlet')
doublets.A23<-read.table('/A23/DoubletFinder/DoubletFinder_doublets_singlets.txt',sep='\t',header=T)
singlets.A23<-subset(doublets.A23,doublets.A23$DoubletFinder_DropletType == 'singlet')
doublets.A29<-read.table('/A29/DoubletFinder/DoubletFinder_doublets_singlets.txt',sep='\t',header=T)
singlets.A29<-subset(doublets.A29,doublets.A29$DoubletFinder_DropletType == 'singlet')
doublets.A19<-read.table('/A19/DoubletFinder/DoubletFinder_doublets_singlets.txt',sep='\t',header=T)
singlets.A19<-subset(doublets.A19,doublets.A19$DoubletFinder_DropletType == 'singlet')
doublets.d5_2<-read.table('/D5_2/DoubletFinder/DoubletFinder_doublets_singlets.txt',sep='\t',header=T)
singlets.d5_2<-subset(doublets.d5_2,doublets.d5_2$DoubletFinder_DropletType == 'singlet')
doublets.A4<-read.table('/A4/DoubletFinder/DoubletFinder_doublets_singlets.txt',sep='\t',header=T)
singlets.A4<-subset(doublets.A4,doublets.A4$DoubletFinder_DropletType == 'singlet')
doublets.A6<-read.table('/A6/DoubletFinder/DoubletFinder_doublets_singlets.txt',sep='\t',header=T)
singlets.A6<-subset(doublets.A6,doublets.A6$DoubletFinder_DropletType == 'singlet')

### subset raw data to retain only the predicted singlets

A8<-subset(A8,cells=singlets.A8$Barcode)
A11<-subset(A11,cells=singlets.A11$Barcode)
A17<-subset(A17,cells=singlets.A17$Barcode)
A27<-subset(A27,cells=singlets.A27$Barcode)
A23<-subset(A23,cells=singlets.A23$Barcode)
A29<-subset(A29,cells=singlets.A29$Barcode)
A19<-subset(A19,cells=singlets.A19$Barcode)
d5_2<-subset(d5_2,cells=singlets.d5_2$Barcode)
A4<-subset(A4,cells=singlets.A4$Barcode)
A6<-subset(A6,cells=singlets.A6$Barcode)

### END OF INGESTING RAW DATA AND DOUBLET PREDICTIONS

# integrate data using commands from https://github.com/satijalab/seurat/issues/1720 and https://github.com/satijalab/seurat/issues/1836 (the latter recommended by Seurat developers)

obj.list=c(A8,A11,A17,A27,A23,A29,A19,d5_2,A4,A6)
features <- SelectIntegrationFeatures(object.list = obj.list, nfeatures = 5000)
obj.list <- PrepSCTIntegration(object.list = obj.list, anchor.features = features)
obj.anchors <- FindIntegrationAnchors(object.list = obj.list, anchor.features = features, normalization.method = "SCT", reduction = "cca")
obj.combined <- IntegrateData(anchorset = obj.anchors, normalization.method = "SCT") # see https://github.com/satijalab/seurat/issues/3930 for discussion of k.weight

# add metadata to our integrated data object: cell barcodes, sample IDs, sampling days

obj.combined@meta.data$barcode <- c(
A8@meta.data$barcode,
A11@meta.data$barcode,
A17@meta.data$barcode,
A27@meta.data$barcode,
A23@meta.data$barcode,
A29@meta.data$barcode,
A19@meta.data$barcode,
d5_2@meta.data$barcode,
A4@meta.data$barcode,
A6@meta.data$barcode
)
obj.combined@meta.data$percent.mt <- c(
A8@meta.data$percent.mt,
A11@meta.data$percent.mt,
A17@meta.data$percent.mt,
A27@meta.data$percent.mt,
A23@meta.data$percent.mt,
A29@meta.data$percent.mt,
A19@meta.data$percent.mt,
d5_2@meta.data$percent.mt,
A4@meta.data$percent.mt,
A6@meta.data$percent.mt
)
obj.combined@meta.data$sample.id <- c(
rep("A8", ncol(A8@assays$RNA$counts)),
rep("A11", ncol(A11@assays$RNA$counts)),
rep("A17", ncol(A17@assays$RNA$counts)),
rep("A27", ncol(A27@assays$RNA$counts)),
rep("A23", ncol(A23@assays$RNA$counts)),
rep("A29", ncol(A29@assays$RNA$counts)),
rep("A19", ncol(A19@assays$RNA$counts)),
rep("d5_2", ncol(d5_2@assays$RNA$counts)),
rep("A4", ncol(A4@assays$RNA$counts)),
rep("A6", ncol(A6@assays$RNA$counts))
)
obj.combined@meta.data$day <- c(
rep("day 0", ncol(A8@assays$RNA$counts)),
rep("day 0", ncol(A11@assays$RNA$counts)),
rep("day 1", ncol(A17@assays$RNA$counts)),
rep("day 1", ncol(A27@assays$RNA$counts)),
rep("day 3", ncol(A23@assays$RNA$counts)),
rep("day 3", ncol(A29@assays$RNA$counts)),
rep("day 5", ncol(A19@assays$RNA$counts)),
rep("day 5", ncol(d5_2@assays$RNA$counts)),
rep("day 7", ncol(A4@assays$RNA$counts)),
rep("day 7", ncol(A6@assays$RNA$counts))
)
obj.combined@meta.data$day <- factor(obj.combined@meta.data$day, levels = c("day 0","day 1","day 3","day 5","day 7"))

# create a UMAP plot for the combined dataset, part 1: determine dimensionality from the elbow plot

DefaultAssay(obj.combined) <- "integrated"
obj.combined <- RunPCA(obj.combined, verbose = FALSE)

pdf('obj_firstPass.elbow_plot.pdf')
options(repr.plot.width=9, repr.plot.height=6)
ElbowPlot(obj.combined, ndims = 50)
dev.off()

# quantify content of the elbow plot. implement code from https://hbctraining.github.io/scRNA-seq/lessons/elbow_plot_metric.html

pct <- obj.combined[["pca"]]@stdev / sum(obj.combined[["pca"]]@stdev) * 100
cumu <- cumsum(pct)
component1 <- which(cumu > 90 & pct < 5)[1] # determine the point where the principal component contributes < 5% of standard deviation and the principal components so far have cumulatively contributed 90% of the standard deviation.
component2 <- sort(which((pct[1:length(pct) - 1] - pct[2:length(pct)]) > 0.1), decreasing = T)[1] + 1 # identify where the percent change in variation between consecutive PCs is less than 0.1%

# let's take the minimum of these two metrics and conclude that at this point the PCs cover the majority of the variation in the data

prin_comp <- min(component1, component2)
write.table(prin_comp,file='obj_firstPass.elbow_PC.txt',row.names=FALSE,col.names=FALSE,quote=FALSE,sep='\t')

# create a UMAP plot for the combined dataset, part 2: the plot itself
# see https://github.com/satijalab/seurat/issues/3953: "we recommend the default k=20 for most datasets. As a rule of thumb you do not want to have a higher k than the number of cells in your least populated cell type"
# so we'll fix k but vary the resolution range to experiment with clustering. Be mindful of the comments on clustering made by https://bmcbioinformatics.biomedcentral.com/articles/10.1186/s12859-021-03957-4: "without foreknowledge of cell types, it is hard to address the quality of the chosen clusters, and whether the cells have been under- or over-clustered. In general, under-clustering occurs when clusters are too broad and mask underlying biological structure. Near-optimal clustering is when most clusters relate to known or presumed cell types, with relevant biological distinctions revealed and without noisy, unreliable, or artifactual sub-populations. When cells are slightly over-clustered, non-relevant subdivisions have been introduced; however, these subclusters can still be merged to recover appropriate cell types. Once severe over-clustering occurs, however, some clusters may be shattered, meaning they are segregated based on non-biological variation to the point where iterative re-merging cannot recover the appropriate cell types."

resolution.range <- seq(from = 0, to = 0.5, by = 0.1)

obj.combined <- FindNeighbors(obj.combined, reduction = 'pca', dims = 1:prin_comp, k.param = 20, verbose = FALSE)
obj.combined <- FindClusters(obj.combined, algorithm=3, resolution = resolution.range, verbose = FALSE)
obj.combined <- RunUMAP(obj.combined, dims = 1:prin_comp, n.neighbors = 20, verbose = FALSE)

# print the UMAP plots, coloured according to clusters and to potential batch effects
# we expect to see that there are NO batch effects: that the clusters are not being established on the basis of sample ID or day

pdf('obj_firstPass.umap.pdf')
tplot = DimPlot(obj.combined, reduction = "umap", label=TRUE, pt.size = .1)
tplot[[1]]$layers[[1]]$aes_params$alpha = 0.5
print(tplot)
dev.off()

pdf('obj_firstPass.grouped_by_sampleID.pdf')
tplot = DimPlot(obj.combined, reduction = "umap", group.by="sample.id")
tplot[[1]]$layers[[1]]$aes_params$alpha = 0.5
print(tplot)
dev.off()

pdf('obj_firstPass.grouped_by_day.pdf')
tplot = DimPlot(obj.combined, reduction = "umap", group.by="day")
tplot[[1]]$layers[[1]]$aes_params$alpha = 0.5
print(tplot)
dev.off()

# print the Clustree plot, so that we may later check which cluster resolution is appropriate
# in the next script, we will re-calculate the clusters according to our manually-chosen resolution

pdf('obj_firstPass.clustree_plot.pdf',paper="a4r")
clustree_fig<-clustree(obj.combined,prefix="integrated_snn_res.")
print(clustree_fig)
dev.off()

# remove extraneous metadata from the data object before export
# note that we are not, at this time, removing the variable obj.combined@meta.data$seurat_clusters but it is worth commenting on: this variable contains the results from FindClusters but because we've run FindClusters with a range of values, it will be iteratively overwritten and thereby contain data from the last value in resolution_range, i.e. obj.combined@meta.data$seurat_clusters == obj.combined@meta.data$integrated_snn_res.1.2
# in our next script we will re-run the clustering having decided on an optimal resolution value. It is in that script that we will tidy up the data object further, and export our finalised metadata

obj.combined@meta.data$SCT_snn_res.0<-NULL
obj.combined@meta.data$SCT_snn_res.0.1<-NULL
obj.combined@meta.data$SCT_snn_res.0.2<-NULL
obj.combined@meta.data$SCT_snn_res.0.3<-NULL
obj.combined@meta.data$SCT_snn_res.0.4<-NULL
obj.combined@meta.data$SCT_snn_res.0.5<-NULL

# save the Seurat object for later use

saveRDS(obj.combined, file = "obj_firstPass.rds")