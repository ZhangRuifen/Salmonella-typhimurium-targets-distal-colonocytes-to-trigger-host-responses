# module add R-base/4.1.0
# module add R-cbrg/202111

library(Seurat)
library(Matrix)
library(glmGamPoi)
library(sctransform)
library(tidyverse)
library(gprofiler2)
library(DoubletFinder)
theme_set(theme_bw())

get_knee_df <- function(mat) {
  total <- rank <- NULL
  tibble(total = Matrix::colSums(mat),
         rank = row_number(desc(total))) %>%
    distinct() %>%
    dplyr::filter(total > 0) %>% 
    arrange(rank)
}

get_inflection <- function(df, lower = 100) {
  log_total <- log_rank <- total <-  NULL
  df_fit <- df %>% 
    dplyr::filter(total > lower) %>% 
    transmute(log_total = log10(total),
              log_rank = log10(rank))
  d1n <- diff(df_fit$log_total)/diff(df_fit$log_rank)
  right.edge <- which.min(d1n)
  10^(df_fit$log_total[right.edge])
}

knee_plot <- function(df, inflection) {
total <- rank_cutoff <- NULL
annot <- tibble(inflection = inflection, rank_cutoff = max(df$rank[df$total > inflection]))
ggplot(df, aes(total, rank)) +
    geom_path() +
    geom_vline(aes(xintercept = inflection), data = annot, linetype = 2, color = "gray40") +
    geom_hline(aes(yintercept = rank_cutoff), data = annot, linetype = 2,color = "gray40") +
    geom_text(aes(inflection, rank_cutoff, label = paste(rank_cutoff, "'cells'")), data = annot, vjust = 1) +
    scale_x_log10() +
    scale_y_log10() +
    labs(y = "Rank", x = "Total UMIs") +
    annotation_logticks()
}

mtx <- Read10X("A29_d3")
obj <- CreateSeuratObject(counts = mtx, project = "A29_d3", min.cells = 3, min.features = 500)
obj[["percent.mt"]] <- PercentageFeatureSet(obj, pattern = "^mt-")

# make knee plot

pdf('A29_d3.knee_plot.pdf')
options(repr.plot.width=9, repr.plot.height=6)
knee_df <- get_knee_df(mtx)
inflection <- get_inflection(knee_df)
knee_plot(knee_df, inflection)
dev.off()

# output a table stating how many cells have x UMIs: this is the basis by which the knee plot implements its filter

num_umis_at_inflection_point<-as.numeric(inflection[[1]])
num_cells_at_inflection_point<-max(knee_df$rank[knee_df$total > inflection])
inflection_df<-data.frame(UMIS=num_umis_at_inflection_point,CELLS=num_cells_at_inflection_point)
write.table(inflection_df,file='A29_d3.inflection_point.txt',row.names=FALSE,col.names=TRUE,quote=FALSE,sep='\t')

# visualise QC metrics as a violin plot

pdf('A29_d3.violin_plots_of_QC_metrics.pdf')
options(repr.plot.width=12, repr.plot.height=6)
VlnPlot(obj, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
dev.off()

# create scatter plots of the % of MT genes, no. of UMIs in each cell, and no. of distinct genes in each cell
# these will help us empirically derive values for filtering cells on the basis of the proportion of mitochondrial genes and the number of RNA molecules captured, excluding those with UMI counts that are too low (indicative of empty or low-quality droplets) or too high (indicative of doublets)

pdf('A29_d3.scatter_plots_to_inform_filtering.pdf')
plot1 <- FeatureScatter(obj, feature1 = "nCount_RNA", feature2 = "percent.mt") + NoLegend()
plot2 <- FeatureScatter(obj, feature1 = "nCount_RNA", feature2 = "nFeature_RNA") + NoLegend()
plot1 + plot2
dev.off()

# filter cells on the basis of nFeature_RNA, nCount_RNA, and percent.mt

num_cells_unfiltered 			<- ncol(mtx)
num_cells_nFeature_RNA_le_1000  <- nrow(subset(obj@meta.data,nFeature_RNA <= 1000))
num_cells_nFeature_RNA_ge_10000 <- nrow(subset(obj@meta.data,nFeature_RNA >= 10000))
num_cells_nCount_RNA_le_2000    <- nrow(subset(obj@meta.data,nCount_RNA <= 2000))
num_cells_nCount_RNA_ge_50000   <- nrow(subset(obj@meta.data,nCount_RNA >= 50000))
num_cells_percentMT_ge_10       <- nrow(subset(obj@meta.data,percent.mt >= 10))

obj <- subset(obj, subset = nFeature_RNA > 1000 & nFeature_RNA < 10000 & nCount_RNA > 2000 & nCount_RNA < 50000 & percent.mt < 10)

num_cells_passing_all_QC_thresholds <- nrow(obj@meta.data)

# apply SCtransform normalisation, regressing out the effect of several variables
# this includes the effect of cell-cycle heterogeneity which we mitigate by calculating cell cycle phase scores (so that we can regress these out too)
# this process is described in https://satijalab.org/seurat/archive/v3.1/cell_cycle_vignette.html and https://github.com/satijalab/seurat/issues/1679, with https://www.biostars.org/p/364214/ detailing the location of lists of cell cycle genes. Those used here are from Table S2 of Dominguez 2018 (https://www.nature.com/articles/cr201684) but others (using human gene names) are pre-loaded in Seurat
# note potential issues with applying the CellCycleScoring function in conjunction with SCTransform (namely, with small datasets, the error message "insufficient data values to produce 24 bins"): https://github.com/satijalab/seurat/issues/1227 and https://github.com/satijalab/seurat/issues/3692

s.genes = gorth(cc.genes.updated.2019$s.genes, source_organism = "hsapiens", target_organism = "mmusculus")$ortholog_name
g2m.genes = gorth(cc.genes.updated.2019$g2m.genes, source_organism = "hsapiens", target_organism = "mmusculus")$ortholog_name
obj <- NormalizeData(obj, assay = 'RNA')
obj <- CellCycleScoring(obj, s.features = s.genes, g2m.features = g2m.genes, assay = 'RNA', set.ident = TRUE)
obj <- SCTransform(obj, method = "glmGamPoi", assay = 'RNA', new.assay.name = 'SCT', vars.to.regress = c("nCount_RNA","nFeature_RNA","percent.mt","S.Score","G2M.Score"))

# determine the dimensionality of the data
# we do this by performing PCA analysis on the scaled data and generating an elbow plot: a ranking of principal components by the percentage of variance explained by each ones

obj <- RunPCA(obj, verbose = FALSE) # note that the default number of principal components analysed is 50 and that there must be more principal components than there are cells. See https://github.com/satijalab/seurat/issues/1914

# quantify content of the elbow plot programmatically. To do this, we implement code from https://hbctraining.github.io/scRNA-seq/lessons/elbow_plot_metric.html

pct <- obj[["pca"]]@stdev / sum(obj[["pca"]]@stdev) * 100
cumu <- cumsum(pct)
component1 <- which(cumu > 90 & pct < 5)[1] # determine the point where the principal component contributes < 5% of standard deviation and the principal components so far have cumulatively contributed 90% of the standard deviation.
component2 <- sort(which((pct[1:length(pct) - 1] - pct[2:length(pct)]) > 0.1), decreasing = T)[1] + 1 # identify where the percent change in variation between consecutive PCs is less than 0.1%

# let us choose the minimum of these two metrics and conclude that at this point the PCs cover the majority of the variation in the data. We will use all PCs up to and including this 'elbow' for downstream analyses, i.e. dimension reduction and UMAP visualisation.

prin_comp <- min(component1, component2)
write.table(prin_comp,file='A29_d3.elbow_PC.txt',row.names=FALSE,col.names=FALSE,quote=FALSE,sep='\t')

# visualise clustering as UMAP

resolution.range <- seq(from = 0, to = 0.5, by = 0.1)

pdf('A29_d3.umap_plot.pdf')
obj <- FindNeighbors(obj, reduction = 'pca', dims = 1:prin_comp, verbose = FALSE)
obj <- FindClusters(obj, algorithm=3, resolution = resolution.range, verbose = FALSE) # from https://satijalab.org/seurat/archive/v3.1/pbmc3k_tutorial.html: the FindClusters function "contains a resolution parameter that sets the '˜granularity' of the downstream clustering, with increased values leading to a greater number of clusters. We find that setting this parameter between 0.4-1.2 typically returns good results for single-cell datasets of around 3K cells. Optimal resolution often increases for larger datasets"
obj <- RunUMAP(obj, dims = 1:prin_comp, verbose = FALSE) # note that the default values for k.param in FindNeighbors (20) and n.neighbors in RunUMAP (30) are different, but both define the number of neighbouring points. Discussed at https://github.com/satijalab/seurat/issues/4717: "if you want to ensure that the UMAP representation and clustering results are as consistent as possible it's a good idea to use the same number of nearest neighbors when building the neighbor graph for clustering and for UMAP". k.param is an especially important parameter with significant effect upon clustering: https://jtggjournal.com/article/view/3809
tplot = DimPlot(obj, reduction = "umap", label=TRUE, pt.size = .1)
tplot[[1]]$layers[[1]]$aes_params$alpha = 0.5
print(tplot)
dev.off()

# export the Seurat metadata
# the number of rows in this table = the number of cells we have used

barcodes<-rownames(obj@meta.data)
obj@meta.data$barcode<-barcodes
write.table(obj@meta.data,file='A29_d3.seurat_metadata.txt',row.names=FALSE,col.names=TRUE,quote=FALSE,sep='\t')

# output a table showing how many cells and how many genes we have

total_genes<-nrow(x=obj)
total_cells<-ncol(x=obj) # = num_cells_passing_all_QC_thresholds
total_df<-data.frame(NUM_CELLS_UNFILTERED=num_cells_unfiltered,NUM_CELLS_WITH_LE_1000_GENES=num_cells_nFeature_RNA_le_1000,NUM_CELLS_WITH_GE_10k_GENES=num_cells_nFeature_RNA_ge_10000,NUM_CELLS_WITH_LE_2k_UMIS=num_cells_nCount_RNA_le_2000,NUM_CELLS_WITH_GE_50k_UMIS=num_cells_nCount_RNA_ge_50000,NUM_CELLS_WITH_PCT_MT_GE_10=num_cells_percentMT_ge_10,NUM_CELLS_PASSING_ALL_QC_FILTERS=total_cells,NUM_GENES_PASSING_ALL_QC_FILTERS=total_genes)
write.table(total_df,file='A29_d3.totals.txt',row.names=FALSE,col.names=TRUE,quote=FALSE,sep='\t')

# detect doublets, following the protocols of https://demultiplexing-doublet-detecting-docs.readthedocs.io/en/latest/DoubletFinder.html AND https://github.com/chris-mcginnis-ucsf/DoubletFinder

# doublet detection (1): pK Identification (no ground-truth)
sweep.res.list <- paramSweep(testis, PCs = 1:10, sct = TRUE)
sweep.stats <- summarizeSweep(sweep.res.list, GT = FALSE)
bcmvn <- find.pK(sweep.stats)

# doublet detection (2): homotypic doublet proportion estimate (we are using a set clustering resolution, 0.4, and a set proportion of expected doublets, 7.5%)
annotations <- testis$SCT_snn_res.0.3
homotypic.prop <- modelHomotypic(annotations)
doublet_number <- round(0.075*nrow(testis@meta.data))
nExp_poi.adj <- round(doublet_number*(1-homotypic.prop))

# doublet detection (3): run DoubletFinder with varying classification stringencies
testis <- doubletFinder(testis, PCs = 1:10, pN = 0.25, pK = as.numeric(as.character(bcmvn$pK[which(bcmvn$BCmetric == max(bcmvn$BCmetric))])), nExp = nExp_poi.adj, reuse.pANN = FALSE, sct = TRUE)
doublets <- as.data.frame(cbind(colnames(testis), testis@meta.data[,grepl(paste0("pANN_0.25_",as.numeric(as.character(bcmvn$pK[which(bcmvn$BCmetric == max(bcmvn$BCmetric))]))), colnames(testis@meta.data))], testis@meta.data[,grepl(paste0("DF.classifications_0.25_",as.numeric(as.character(bcmvn$pK[which(bcmvn$BCmetric == max(bcmvn$BCmetric))]))), colnames(testis@meta.data))]))
colnames(doublets) <- c("Barcode","DoubletFinder_score","DoubletFinder_DropletType")
doublets$DoubletFinder_DropletType <- gsub("Singlet","singlet",doublets$DoubletFinder_DropletType) %>% gsub("Doublet","doublet",.)
write_delim(doublets, file = "DoubletFinder/A29_d3.DoubletFinder_doublets_singlets.txt", delim = "\t")

# doublet detection (4): calculate number of doublets and singlets
summary <- as.data.frame(table(doublets$DoubletFinder_DropletType))
colnames(summary) <- c("Classification", "Droplet N")
write_delim(summary, file = "DoubletFinder/DoubletFinder_doublet_summary.txt", delim = "\t")

# export the Seurat object for later integration

saveRDS(obj, file = "A29_d3.rds")