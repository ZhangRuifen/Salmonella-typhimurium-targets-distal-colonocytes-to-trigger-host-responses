### Fig1H ###
obj_new_annotation <- readRDS("G://obj_new_annotation.rds")


group<-table(obj_new_annotation$CellType,obj_new_annotation$day)
group<-as.data.frame(group)
head(group)
colnames(group)<-c('CellType','day','number')
"#E95351"
color <- c( "#FDBF6F","#fddbc8","#FFFF99","#E95351","#CAB2D6","#B15928",
             "#1F78B4","#A6CEE3","#FB9A99","#6A3D9A","#B2DF8A","#33A02C","#FF7F00") 

p<-ggplot(group, aes(x=number, y=day, fill=CellType)) +
  geom_bar(stat="identity", position=position_fill()) +
  scale_fill_manual(values = c("Macrophage"="#FDBF6F", "T_cells"="#fddbc8", "Progenitor_CC"="#FFFF99", "Goblets"="#E95351",
                               "CC_2"="#CAB2D6", "Stem/TA"="#B15928", "CC_1"="#1F78B4",         
                               "B_cells"="#A6CEE3", "Fibroblast"= "#FB9A99", "Plasma"= "#6A3D9A", 
                               "EEC"="#B2DF8A", "Endothelial"="#33A02C", "Neutrophil"="#FF7F00"))

ggsave(plot=p,filename="obj_new_annotation_DimPlot.pdf",unit="mm",width=180,height=150)