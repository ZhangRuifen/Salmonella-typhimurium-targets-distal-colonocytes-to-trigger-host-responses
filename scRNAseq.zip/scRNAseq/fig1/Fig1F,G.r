### Fig1F ###
library(RColorBrewer)
library(Seurat)
library(tidyverse)
library(mascarade)
library(data.table)


DimPlot(obj_new_annotation,group.by= "sample.id", split.by= "day")
DimPlot(obj_new_annotation,group.by= "sample.id")
DimPlot(obj_new_annotation)

DimPlot(obj_new_annotation,group.by = c("CellType","RNA_snn_res.0.2"),label = TRUE)
unique(obj_new_annotation$CellType)

obj_new_annotation@meta.data$CellType[obj_new_annotation@meta.data$RNA_snn_res.0.2%in% c(0)] <- "CC_1"
obj_new_annotation@meta.data$CellType[obj_new_annotation@meta.data$RNA_snn_res.0.2%in% c(1)] <- "Stem/TA"
obj_new_annotation@meta.data$CellType[obj_new_annotation@meta.data$RNA_snn_res.0.2%in% c(2)] <- "CC_2"
obj_new_annotation@meta.data$CellType[obj_new_annotation@meta.data$RNA_snn_res.0.2%in% c(3)] <- "Goblets"
obj_new_annotation@meta.data$CellType[obj_new_annotation@meta.data$RNA_snn_res.0.2%in% c(4)] <- "Progenitor_CC"
obj_new_annotation@meta.data$CellType[obj_new_annotation@meta.data$RNA_snn_res.0.2%in% c(5,16)] <- "Macrophage"
obj_new_annotation@meta.data$CellType[obj_new_annotation@meta.data$RNA_snn_res.0.2%in% c(6,7)] <- "T_cells"
obj_new_annotation@meta.data$CellType[obj_new_annotation@meta.data$RNA_snn_res.0.2%in% c(8)] <- "Plasma"
obj_new_annotation@meta.data$CellType[obj_new_annotation@meta.data$RNA_snn_res.0.2%in% c(9,11)] <- "Fibroblast"
obj_new_annotation@meta.data$CellType[obj_new_annotation@meta.data$RNA_snn_res.0.2%in% c(10)] <- "B_cells"
obj_new_annotation@meta.data$CellType[obj_new_annotation@meta.data$RNA_snn_res.0.2%in% c(12)] <- "EEC"
obj_new_annotation@meta.data$CellType[obj_new_annotation@meta.data$RNA_snn_res.0.2%in% c(13)] <- "Endothelial"
obj_new_annotation@meta.data$CellType[obj_new_annotation@meta.data$RNA_snn_res.0.2%in% c(14)] <- "Neutrophil"
obj_new_annotation@meta.data$CellType[obj_new_annotation@meta.data$RNA_snn_res.0.2%in% c(15)] <- "Adipocyte"


# A.Epithelial(5个): CC_1,Stem/TA,CC_2,Goblets,Progenitor_CC  
"#EBAEA9","#EBCC96","#CBE5DE","#EED0E0","#CB95BB"
# B.Immune(5个): Macrophage,Plasma,B_cells,T_cells,Neutrophil
"#95A6DA","#BFA6C9","#F5E0BA","#AED0DF","#89B780",
# C.Stromal(1个): Fibroblast
"#F5D8D0"
# D.Others(3个): EEC,Endothelial,Adipocyte
"#83B4EF","#7EC0C3","#AAD0AC"

Idents(obj_new_annotation)<- obj_new_annotation$CellType

new_order <- c("Stem/TA","Progenitor_CC","CC_1","CC_2","Goblets",
               "Macrophage","Plasma","B_cells","T_cells","Neutrophil",
               "Fibroblast","EEC","Endothelial","Adipocyte")
colors <- c( "#bf0603","#f06152","#FF7F00","#FB9A99","#fddbc8",
             "#6A3D9A","#33A02C","#76D7C4","#B2DF8A","#CAB2D6",
             "#1F78B4","#A6CEE3","#B15928","#FDBF6F")

obj_new_annotation$seurat_clusters <- factor(Idents(obj_new_annotation), levels = new_order) # 将最新顺序放到“Seurat_Cluster”中
Idents(obj_new_annotation) <- obj_new_annotation$seurat_clusters
DimPlot(obj_new_annotation,cols = colors)


Idents(obj_new_annotation)<-obj_new_annotation$CellType
markers<-FindAllMarkers(obj_new_annotation,only.pos = TRUE,logfc.threshold = 0.25)
write.csv(markers,file = "/data/home/rfzhang/project/singlecelldata/the_newest/celltype_markers.csv")

# 3. 绘制FeaturePlot图
FeaturePlot(obj_new_annotation,features=c("Ly6g","Fabp2"))
Idents(obj_new_annotation)<- obj_new_annotation$CellType
DimPlot(obj_new_annotation,cols = colors,split.by = "day")

# 给汇总大图配色
# 上皮11类
p<-ggplot(group, aes(x=number, y=day, fill=subCellType)) +
  geom_bar(stat="identity", position=position_fill()) +
  scale_fill_manual(values = c("Stem/TA"="#1F78B4",  
                               "Goblet_0"="#A6CEE3", "Goblet_1"= "#B2DF8A", "PCC"="#33A02C",      
                               "Mid_CC"= "#FB9A99",   "pre_DCC"="#E95351",  "DCC"="#FDBF6F", "Pre_PCC"="#FF7F00",  
                               "M_cell"="#CAB2D6",   "Goblet_2"="#6A3D9A", "EEC"="#FFFF99"))
DimPlot(re_Epi,cols=color)


colors <- c(
  "#FF0000", "#00FF00", "#0000FF", "#FFFF00", "#00FFFF", "#FF00FF",
  "#FFA500", "#800080", "#008080", "#4B0082", "#FFC0CB", "#A52A2A",
  "#FFD700", "#C0C0C0", "#808080", "#000080", "#BFFF00", "#FF1493",
  "#808000", "#008000", "#4682B4", "#DC143C", "#00CED1", "#ADFF2F",
  "#7B68EE", "#FF4500", "#32CD32"
)


group$CellType <- factor(group$CellType, levels = rev(c("Stem/TA","Progenitor_CC","CC_1","CC_2","Goblets",
                                                    "Macrophage","Plasma","B_cells","T_cells","Neutrophil",
                                                    "Fibroblast","EEC","Endothelial","Adipocyte")))


color<-c()
p<-ggplot(group, aes(x=number, y=day, fill=CellType)) +
  geom_bar(stat="identity", position=position_fill()) +
  scale_fill_manual(values = c("Stem/TA"="#bf0603",  "Progenitor_CC"="#f06152","CC_1"="#FF7F00","CC_2"="#FB9A99","Goblets"="#fddbc8",
                               "Macrophage"="#6A3D9A","Plasma"="#33A02C","B_cells"="#76D7C4","T_cells"="#B2DF8A","Neutrophil"="#CAB2D6",
                               "Fibroblast"="#1F78B4","EEC"="#A6CEE3","Endothelial"="#B15928","Adipocyte"="#FDBF6F"))
p
ggsave(plot=p,filename="propotion.pdf",unit="mm",width=180,height=120)

