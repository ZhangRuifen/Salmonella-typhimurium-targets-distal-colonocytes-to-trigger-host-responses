### Fig2B ###

```
library(tidyverse)
library(purrr)
library(Augur)
```

```
obj<-JoinLayers(obj)
comparisons = list(
  c("day 0", "day 1"),
  c("day 0", "day 3"),
  c("day 0", "day 5"),
  c("day 0", "day 7"))
pairwise_results_1 = list()
```

```
for (comparison in comparisons) {
  Idents(obj) = obj$day
  sub = subset(obj, idents = comparison)
  augur = calculate_auc(sub, label_col = "day", cell_type_col =  "CellType",subsample_size = 6)
  comparison_name = paste(comparison, collapse = ":")
  pairwise_results_1[[comparison_name]] = augur
}
```

```
p1<-plot_lollipop(pairwise_results_1[[1]])
p2<-plot_lollipop(pairwise_results_1[[2]])
p3<-plot_lollipop(pairwise_results_1[[3]])
p4<-plot_lollipop(pairwise_results_1[[4]])

```
p5<-plot_umap(pairwise_results_1[[1]],reduction = "umap",obj,cell_type_col = "CellType")
p6<-plot_umap(pairwise_results_1[[1]],reduction = "umap",obj,cell_type_col = "CellType")
p7<-plot_umap(pairwise_results_1[[1]],reduction = "umap",obj,cell_type_col = "CellType")
p8<-plot_umap(pairwise_results_1[[1]],reduction = "umap",obj,cell_type_col = "CellType")
```

```
pdf('obj_augur.pdf',width = 4,height = 3)
print(p1)
print(p2)
print(p3)
print(p4)
dev.off()
```




