### Fig2A,H ###

# 对重新降维聚类的Epithelial进行irGSEA
library(dplyr)
library(ggplot2)
library(dplyr)
library(ggpubr)
library(irGSEA)
library(Seurat)
library(SeuratData)
library(RcppML)

# install packages from CRAN
cran.packages <- c("msigdbr", "dplyr", "purrr", "stringr","magrittr",
                   "RobustRankAggreg", "tibble", "reshape2", "ggsci",
                   "tidyr", "aplot", "ggfun", "ggplotify", "ggridges", 
                   "gghalves", "Seurat", "SeuratObject", "methods", 
                   "devtools", "BiocManager","data.table","doParallel",
                   "doRNG")
if (!requireNamespace(cran.packages, quietly = TRUE)) { 
  install.packages(cran.packages, ask = F, update = F)
}

# install packages from Bioconductor
bioconductor.packages <- c("GSEABase", "AUCell", "SummarizedExperiment", 
                           "singscore", "GSVA", "ComplexHeatmap", "ggtree", 
                           "Nebulosa")
if (!requireNamespace(bioconductor.packages, quietly = TRUE)) { 
  BiocManager::install(bioconductor.packages, ask = F, update = F)
}
# install packages from Github
if (!requireNamespace("UCell", quietly = TRUE)) { 
  devtools::install_github("carmonalab/UCell")
}
if (!requireNamespace("irGSEA", quietly = TRUE)) { 
  devtools::install_github("chuiqin/irGSEA")
}




Salmonella<-keggGet('mmu05132')
Salmonella_infectious<-Salmonella[[1]][["GENE"]]
Salmonella_infectious<-Salmonella_infectious%>%as.data.frame()
Salmonella_infectious <- Salmonella_infectious[!apply(Salmonella_infectious, 1, function(row) all(grepl("^//d+$", row))), ]
Salmonella_infectious<-Salmonella_infectious%>%as.data.frame()
colnames(Salmonella_infectious)<-c("Symbol")
Salmonella_infectious$Symbol<-sub(";.*", "", Salmonella_infectious$Symbol)
Salmonella_infectious<-Salmonella_infectious[c(-26,-72),]

STM<-read.csv("D://salmonella_enriched_all_ID.CSV")
STM<-STM$SYMBOL

marker<-list(Salmonella_infectious,STM)
names(marker)<-c("Salmonella_infectious","STM")

Idents(rename_Epithelial)<-rename_Epithelial$day
obj_d0<-subset(rename_Epithelial,subset = day =="day 0")
obj_d1<-subset(rename_Epithelial,subset = day =="day 1")
obj_d3<-subset(rename_Epithelial,subset = day =="day 3")
obj_d5<-subset(rename_Epithelial,subset = day =="day 5")
obj_d7<-subset(rename_Epithelial,subset = day =="day 7")

obj.final_0 <- irGSEA.score(object = obj_d0,assay = "RNA", 
                            slot = "data", seeds = 123, ncores = 1,
                            min.cells = 3, min.feature = 0,
                            custom = T, geneset = marker,      #修改为新的自定义的geneset: markers
                            msigdb = F, 
                            species = "Mus musculus", category = "C2",
                            subcategory = 'CP:KEGG', geneid = "symbol",
                            method = c("UCell"),
                            aucell.MaxRank = NULL, ucell.MaxRank = NULL, 
                            kcdf = 'Gaussian')

obj.final_1 <- irGSEA.score(object = obj_d1,assay = "RNA", 
                            slot = "data", seeds = 123, ncores = 1,
                            min.cells = 3, min.feature = 0,
                            custom = T, geneset = marker,      #修改为新的自定义的geneset: markers
                            msigdb = F, 
                            species = "Mus musculus", category = "C2",
                            subcategory = 'CP:KEGG', geneid = "symbol",
                            method = c("UCell"),
                            aucell.MaxRank = NULL, ucell.MaxRank = NULL, 
                            kcdf = 'Gaussian')
obj.final_3 <- irGSEA.score(object = obj_d3,assay = "RNA", 
                            slot = "data", seeds = 123, ncores = 1,
                            min.cells = 3, min.feature = 0,
                            custom = T, geneset = marker,      #修改为新的自定义的geneset: markers
                            msigdb = F, 
                            species = "Mus musculus", category = "C2",
                            subcategory = 'CP:KEGG', geneid = "symbol",
                            method = c("UCell"),
                            aucell.MaxRank = NULL, ucell.MaxRank = NULL, 
                            kcdf = 'Gaussian')
obj.final_5 <- irGSEA.score(object = obj_d5,assay = "RNA", 
                            slot = "data", seeds = 123, ncores = 1,
                            min.cells = 3, min.feature = 0,
                            custom = T, geneset = marker,      #修改为新的自定义的geneset: markers
                            msigdb = F, 
                            species = "Mus musculus", category = "C2",
                            subcategory = 'CP:KEGG', geneid = "symbol",
                            method = c("UCell"),
                            aucell.MaxRank = NULL, ucell.MaxRank = NULL, 
                            kcdf = 'Gaussian')
obj.final_7 <- irGSEA.score(object = obj_d7,assay = "RNA", 
                            slot = "data", seeds = 123, ncores = 1,
                            min.cells = 3, min.feature = 0,
                            custom = T, geneset = marker,      #修改为新的自定义的geneset: markers
                            msigdb = F, 
                            species = "Mus musculus", category = "C2",
                            subcategory = 'CP:KEGG', geneid = "symbol",
                            method = c("UCell"),
                            aucell.MaxRank = NULL, ucell.MaxRank = NULL, 
                            kcdf = 'Gaussian')

DefaultAssay(obj_d7)
Idents(obj.final_0)<-obj.final_0@meta.data$subCelltype
Idents(obj.final_1)<-obj.final_1@meta.data$subCelltype
Idents(obj.final_3)<-obj.final_3@meta.data$subCelltype
Idents(obj.final_5)<-obj.final_5@meta.data$subCelltype
Idents(obj.final_7)<-obj.final_7@meta.data$subCelltype

setwd("G:/scRNAseq相关/Figure/FigS2/FigS2E")
####  2.不同天绘制散点图并保存
obj.list<-list(obj.final_0,obj.final_1,obj.final_3,obj.final_5,obj.final_7)
day<-c("d0","d1","d3","d5","d7")
for (i in 1:5)  {
  scatterplot <- irGSEA.density.scatterplot(object = obj.list[[i]],
                                          method = "UCell",
                                          show.geneset = "STM",
                                          reduction = "umap")+
  #labs(y="",x="") +
  theme(legend.position = "right",
        plot.title = element_text(size = 15, hjust = 0.5, face = "bold"), 
        axis.title.x = element_text(size = 10),  
        axis.title.y = element_text(size = 10), 
        axis.text.x = element_text(size = 10),  
        axis.text.y = element_text(size = 10), 
        legend.text = element_text(size = 10),  
        legend.title = element_text(size = 10)   
  )+
  ggplot2::scale_color_gradientn(
    colors = c("#a9def9","#ffd670","#d80032"), 
       limits = c(0,0.0004),            
    breaks = c(0.0001,0.0002,0.0003), 
    name = 'density',
    oob = scales::squish     
  )+ ggtitle("Salmonella Infection Signature")
  filename=paste(day[i],"pdf",sep='.')
  ggsave(scatterplot,file=filename,units = "mm",width = 120,height = 100)
  
}

for (i in 1:5)  {
  scatterplot <- irGSEA.density.scatterplot(object = obj.list[[i]],
                                            method = "UCell",
                                            show.geneset = "STM",
                                            reduction = "umap")+ ggtitle("Salmonella Infection Signature")
  filename=paste(day[i],"pdf",sep='.')
  filename=paste("原配色",filename,sep='.')
  ggsave(scatterplot,file=filename,units = "mm",width = 120,height = 100)
  
}

####  3.DCC，pre_DCC

density.list<-list()
final_list<-list(obj.final_0,obj.final_1,obj.final_3,obj.final_5,obj.final_7)
for (i in 1:5) {
  SeuratObject::DefaultAssay(final_list[[i]]) <- "UCell"
  density_plot <- Nebulosa::plot_density(
    object = final_list[[i]],
    features = "Salmonella-infectious",
    reduction = "umap")
  
  density.list[[i]]<-density_plot[["data"]]
}

# b.celltype
data_subCelltype<-list()
for (i in 1:5) {
  data<-density.list[[i]] # 提取不同天经Nebulosa::plot_density计算的密度结果
  object = final_list[[i]]$subCelltype    # 与不同天的subCelltype信息进行对应
  subCelltype<-final_list[[i]]$subCelltype %>% as.data.frame()
  colnames(subCelltype)<-"subCelltype"
  data_subCelltype[[i]]<-cbind(data,subCelltype)
}


DCC_data<-list()
day<-c("day0","day1","day3","day5","day7")
for (i in 1:5) {
  DCC_data[[i]]<-data_subCelltype[[i]][data_subCelltype[[i]]$subCelltype=="DCC",]
  
  DCC_data[[i]]$day<-day[i]
  
}

names(DCC_data)<-c("d0","d1","d3","d5","d7")

DCC_dataaa <- bind_rows(DCC_data)


write.csv(DCC_dataaa,file="irGSEA_DCC.csv")
####  4.BoxPlot
# a.DCC
p<-ggplot(DCC_dataaa, aes(x=day, y=feature, fill=day, color=day)) +
  geom_boxplot(outlier.shape = NA) +  
  scale_fill_manual(values = c(
    "day0" = "#1f77b4",  
    "day1" = "#ff7f0e",  
    "day3" = "#d62728", 
    "day5" = "#2ca02c",
    "day7" = "#9467bd"  
  )) + 
  scale_color_manual(values = c(
    "day0" = "#1f55a3", 
    "day1" = "#d46c07", 
    "day3" = "#9e2020", 
    "day5" = "#1f7f1f",
    "day7" = "#6e4c8c" 
  )) +  
  theme_ipsum() +
  theme(
    legend.position="none",
    plot.title = element_text(size=11), 
    axis.line = element_line(color = "black", size = 0.5),
    panel.grid.major = element_blank(), 
    panel.grid.minor = element_blank() 
  ) +
  ggtitle("Salmonella Infection Signature") + 
  xlab("") +  
  stat_compare_means(method = "wilcox.test", label = "p.signif", 
                     comparisons = list(c("day1", "day0"), c("day3", "day0"), c("day5", "day0"), c("day7", "day0")))
p
ggsave(plot= p,filename = "DCC_UCell.pdf",units = "mm",width = 150,height = 150, device = cairo_pdf)




########################################## 2.day1 ##########################################

d1<-data_subCelltype[[2]]
d1
unique(d1$subCelltype)


cell_colors_border <- c("Stem/TA"="#E31A1C","Pre_DCC"="#FF7F00","DCC"="#FDBF6F","Pre_PCC"="#1F78B4","PCC"= "#A6CEE3" ,"Mid_CC"= "#FB9A99",
  "Goblet_0"="#777e41", "Goblet_1"="#33A02C", "Goblet_2"= "#B2DF8A",
  "M_cell"="#6A3D9A", "EEC"="#e9bc00")

cell_colors_fill <- c("Stem/TA" = "#D77A7A", 
  "Pre_DCC" = "#EFA548", 
  "DCC" = "#F4D39D", 
  "Pre_PCC" = "#5A8EB5", 
  "PCC" = "#A9C9D4", 
  "Mid_CC" = "#F4B0B0", 
  "Goblet_0" = "#A0A86A", 
  "Goblet_1" = "#78B675", 
  "Goblet_2" = "#C4E2B4", 
  "M_cell" = "#8E77B0", 
  "EEC" = "#F1D85C")


cell_colors_fill <- c(
  "DCC" = "#CBD5E8",
  "Pre_PCC" = "#FDDBC7",
  "Goblet_0" = "#E5D8BD",
  "Mid_CC" = "#F4CAE4",
  "PCC" = "#F7F7F7",
  "Goblet_1" = "#D9D9D9",
  "Stem/TA" = "#B3E2CD",
  "Goblet_2" = "#FDCDAC",
  "Pre_DCC" = "#CBD5E8",
  "EEC" = "#F4A582",
  "M_cell" = "#92C5DE"
)

cell_colors_border <- c(
  "DCC" = "#73849E",
  "Pre_PCC" = "#B5677A",
  "Goblet_0" = "#AA947C",
  "Mid_CC" = "#BA6C98",
  "PCC" = "#AAAAAA",
  "Goblet_1" = "#8C8C8C",
  "Stem/TA" = "#7AAB9C",
  "Goblet_2" = "#AB8674",
  "Pre_DCC" = "#73849E",
  "EEC" = "#9B665A",
  "M_cell" = "#5F849C"
)

comparisons <- lapply(unique(d1$subCelltype[d1$subCelltype != "DCC"]), function(x) c("DCC", x))
comparisons<-list(c("DCC", "PCC"), c("DCC","Mid_CC"), c("DCC","Goblet_2"), c("DCC","Pre_PCC"),
              c("DCC","Goblet_0"),c("DCC","Goblet_1"),c("DCC","Stem/TA"),
               c("DCC","Pre_DCC"),c("DCC", "EEC"),c("DCC","M_cell"))
               

unique(d1$subCelltype)
d1$subCelltype <- factor(d1$subCelltype, levels = c(
  "DCC","PCC","Mid_CC", "Goblet_2","Pre_PCC", "Goblet_0","Goblet_1",     
  "Stem/TA","Pre_DCC",  "EEC", "M_cell"
))

p<-ggplot(d1, aes(x = subCelltype, y = feature, fill = subCelltype, color = subCelltype)) +
  geom_boxplot(outlier.shape = NA) + 
  scale_fill_manual(values = cell_colors_fill) +  
  scale_color_manual(values = cell_colors_border) + 
  theme_minimal() +
  theme(
    legend.position = "none",  
    plot.title = element_text(size = 11, face = "bold", hjust = 0.5),  
    axis.text.x = element_text(angle = 45, hjust = 1), 
    panel.grid.major = element_line(color = "gray90"), 
    panel.grid.minor = element_blank()  
  ) +
  ggtitle("Salmonella Infection Signature") +
  xlab("") + 
  ylab("Feature Value") +  
  stat_compare_means(
    method = "wilcox.test",  
    label = "p.signif",  
    comparisons = comparisons, 
    hide.ns = TRUE  
  )+theme(axis.text = element_text(colour = 'black'),
         axis.text.y = element_text(angle = 90, hjust = 0.5),
         panel.border = element_blank(),
         panel.grid.major = element_blank(), 
         panel.grid.minor = element_blank(),  
         axis.line = element_line(color = "black", size = 0.5)
  ) 
p


