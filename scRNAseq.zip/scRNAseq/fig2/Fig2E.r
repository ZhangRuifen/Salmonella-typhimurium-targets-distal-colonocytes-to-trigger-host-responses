library(Seurat)
library(clustree)

Idents(obj)
Epithelial<-obj[,obj@meta.data$seurat_clusters %in% c(0,1,2,3,7)]

Epi.list <- SplitObject(Epithelial, split.by = "sample.id")  

s.genes <- c("E2f1","Ccne1","Ccne2","Pold3","Dtl","Mcm6","Pcna","Chaf1a","Slbp","Ung","Cdc6","Mcm2","Pask","Hspb8","Exo1","Rfc4") # from Dominguez 2018. N.B. Seurat provides its own list at s.genes <- cc.genes.updated.2019$s.genes
g2m.genes <- c("Gtse1","Gpsm2","Ccnf","Kif11","H2afx","Cdca8","Nde1","Espl1","Ccna2","Kif23","Gpr126","Kif22","Arhgap11a","Bub3","Hmg2b2","Top2a","Brd8","Ube2c","Nusap1","Cks1b","Cdc25c","Fam64a","Cenpe","Ckap2","Nek2","Cdca3","Mki67","Bub1","Tpx2","Plk1","Cks2","Ube2s","Cdc20","Ccnb1","Kpna2","Ttk","Hmmr","Spag5","Cenpf","Cdc25b","Hmgb3","Kif2c","Tacc3","Bub1b","Ccnb2","Lbr","Birc5","Pttg1","Troap","Prc1","Sfpq") 


for (i in 1:length(Epi.list)) {
  Epi.list[[i]] <- NormalizeData(Epi.list[[i]], verbose = TRUE)
  Epi.list[[i]] <- CellCycleScoring(Epi.list[[i]], s.features = s.genes, g2m.features = g2m.genes, assay = 'RNA', set.ident = TRUE)
  Epi.list[[i]] <- SCTransform(Epi.list[[i]], method = "glmGamPoi", assay = 'RNA', new.assay.name = 'SCT', vars.to.regress = c("nCount_RNA","nFeature_RNA","percent.mt","S.Score","G2M.Score"))
} 


integ_features <- SelectIntegrationFeatures(object.list = Epi.list,nfeatures = 5000)
Epi.list <- PrepSCTIntegration(object.list = Epi.list, 
                                   anchor.features = integ_features)
integ_anchors <- FindIntegrationAnchors(object.list = Epi.list, 
                                        normalization.method = "SCT", 
                                        anchor.features = integ_features)
#最终根据锚点将不同样本进行整合
Epi_integrated <- IntegrateData(anchorset = integ_anchors, 
                                   normalization.method = "SCT")
saveRDS(Epi_integrated, "E://Epi_integrated.rds")


Epi_integrated <- RunPCA(object = Epi_integrated)

PCAPlot(Epi_integrated,
        split.by = "sample.id")


ElbowPlot(Epi_integrated,ndims = 50)

pct <- Epi_integrated[["pca"]]@stdev / sum(Epi_integrated[["pca"]]@stdev) * 100 
cumu <- cumsum(pct) #计算向量的累计和
component1 <- which(cumu > 90 & pct < 5)[1] 

component2 <- sort(which((pct[1:length(pct) - 1] - pct[2:length(pct)]) > 0.1), decreasing = T)[1] + 1 
prin_comp <- min(component1, component2)



Epi_integrated <- FindNeighbors(object = Epi_integrated, reduction = 'pca',dims = 1:prin_comp)
resolution.range <- seq(from = 0, to = 0.5, by = 0.1)
Epi_integrated <- FindClusters(object = Epi_integrated,resolution = resolution.range)
T<-clustree(Epi_integrated) 

ggsave(plot = T,filename = 'E://Epi_clusteree.pdf',width = 150,height = 200,units = "mm",limitsize = FALSE)


Epi_integrated <- RunUMAP(Epi_integrated, dims = 1:prin_comp, verbose = FALSE) # note that the default values for k.param in FindNeighbors (20) and n.neighbors in RunUMAP (30) are different, but both define the number of neighbouring points. Discussed at https://github.com/satijalab/seurat/issues/4717: "if you want to ensure that the UMAP representation and clustering results are as consistent as possible it's a good idea to use the same number of nearest neighbors when building the neighbor graph for clustering and for UMAP". k.param is an especially important parameter with significant effect upon clustering: https://jtggjournal.com/article/view/3809
# Plot the UMAP
p1<-DimPlot(Epi_integrated, reduction = "umap", group.by = "integrated_snn_res.0.1", label="T")
p2<-DimPlot(Epi_integrated, reduction = "umap", group.by = "integrated_snn_res.0.2", label="T")
p3<-DimPlot(Epi_integrated, reduction = "umap", group.by = "integrated_snn_res.0.3", label="T")
p4<-DimPlot(Epi_integrated, reduction = "umap", group.by = "integrated_snn_res.0.4", label="T")
p5<-DimPlot(Epi_integrated, reduction = "umap", group.by = "integrated_snn_res.0.5", label="T")
p1+p2+p3+p4+p5
ggsave(plot =p1+p2+p3+p4+p5,filename = 'E://Epi_dif_resolution.pdf',width = 350,height = 250,units = "mm",limitsize = FALSE)

