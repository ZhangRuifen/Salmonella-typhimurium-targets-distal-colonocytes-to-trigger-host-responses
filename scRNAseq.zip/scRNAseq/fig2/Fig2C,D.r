library(CellChat)
install.packages(c("devtools", "remotes", "BiocManager")) 
BiocManager::install(c("SingleCellExperiment", "SummarizedExperiment", "GenomicRanges", "rGREAT", "scran", "scater", "Rtsne", "igraph"))
library(SingleCellExperiment)
library(SummarizedExperiment)
library(GenomicRanges)
library(rGREAT)
library(scran)
library(scater)
library(Rtsne)
library(igraph)
library(patchwork)

install.packages('NMF')
devtools::install_github("jokergoo/circlize")
devtools::install_github("jokergoo/ComplexHeatmap")


DefaultAssay(obj_new_annotation)
obj_new_annotation<-JoinLayers(obj_new_annotation)
obj.list<-SplitObject(obj_new_annotation,split.by = 'day')
data.input = obj.list[["day 1"]]@assays[["RNA"]]@layers[["data"]]
labels <- Idents(obj.list[["day 1"]])
meta <- data.frame(labels = labels, row.names = names(labels)) 

CellChat <- createCellChat(object = obj.list[["day 1"]], group.by = "ident", assay = "RNA")
groupSize <- as.numeric(table(CellChat@idents)) 

CellChatDB <- CellChatDB.mouse
showDatabaseCategory(CellChatDB)
CellChatDB.use <- CellChatDB # simply use the default CellChatDB
CellChat@DB <- CellChatDB.use

CellChat <- subsetData(CellChat) # This step is necessary even if using the whole database
CellChat <- identifyOverExpressedGenes(CellChat)  
CellChat <- identifyOverExpressedInteractions(CellChat)

CellChat <- computeCommunProb(CellChat, population.size = TRUE) 
CellChat <- filterCommunication(CellChat, min.cells = 10) 

df.net <- subsetCommunication(cellchat) 
write.csv(df.net, "d7_net_lr.csv")


CellChat <- computeCommunProbPathway(CellChat) 
head(CellChat@net)
head(CellChat@netP)

CellChat <- aggregateNet(CellChat)


#### Visualization ####

groupSize <- as.numeric(table(CellChat@idents))

par(mfrow = c(1,2), xpd=TRUE) 
netVisual_circle(CellChat@net$count, vertex.weight = groupSize,
                 weight.scale = T, label.edge= F,
                 title.name = "Number of interactions")
netVisual_circle(CellChat@net$weight, vertex.weight = groupSize,
                 weight.scale = T, label.edge= F,
                 title.name = "Interaction weights/strength")
dev.off()

mat <- CellChat@net$weight
mat<- as.data.frame(mat)
par(mfrow = c(3,5), mar = c(2, 2, 2, 2), xpd=TRUE)
for (i in 1:nrow(mat)) 
    {
  mat2 <- matrix(0, nrow = nrow(mat), ncol = ncol(mat), dimnames = dimnames(mat))
  mat2<- as.data.frame(mat2)
  mat2[i, ] <- mat[i, ]
  mat2 <- as.matrix(mat2)
  netVisual_circle(mat2, vertex.weight = groupSize,
                   weight.scale = T, edge.weight.max = max(mat),
                   title.name = rownames(mat)[i])
  }
dev.off()
getwd()


getwd()
groupSize <- as.numeric(table(cellchat_d1@idents))
netVisual_circle(cellchat_d1@net$weight, vertex.weight = groupSize,
                 weight.scale = T, label.edge= F,
                 title.name = paste0("Interaction weights/strength - ", names(object.list)[i]),
                 targets.use = 'T_cells')
current_cell_order <- colnames(cellchat_d1@net[["weight"]])
new_index <- match(new_cell_order, current_cell_order) 


object.list <- list(d0 = cellchat_d0, d1 = cellchat_d1,d3 = cellchat_d3, d5 = cellchat_d5,d7 = cellchat_d7)


new_cell_order <- c( "B_cells", "Plasma","Neutrophil", "Stem/TA","Progenitor_CC",
                     "CC_1", "CC_2", "Goblets", "EEC", "Endothelial",
                     "Fibroblast", "Macrophage","T_cells")  

for(i in 1:5){
  # 2.获取当前列名（细胞顺序）
  current_cell_order <- colnames(object.list[[i]]@net[["weight"]])
  
  # 3.创建新的排序索引
  # 创建新的排序索引
   # 按new_order的顺序，对old_order特定细胞类型的排序位置进行确定
  new_index <- match(new_cell_order, current_cell_order) 
  
  # 4.重新排序矩阵
  # 提取当前矩阵
  weight_matrix <- object.list[[i]]@net[["weight"]]
  # 重新排序矩阵 [行索引,列索引]
  sorted_weight_matrix <- weight_matrix[new_index, new_index]
  
  # 5.赋值给Cellchat中的net[[“weight"]]对象
  object.list[[i]]@net[["weight"]] <- sorted_weight_matrix
  
  # 6.metadata中的celltype列 按照上述顺序进行排序
  object.list[[i]]@meta$CellType <- factor(object.list[[i]]@meta$CellType, 
                                           levels = new_cell_order)
}


### 绘制3种类免疫细胞互作图 ###
par(mfrow = c(1,5), xpd=TRUE)
for (i in 1:5){
  groupSize <- table(object.list[[i]]@meta$CellType)
  netVisual_circle(object.list[[i]]@net$weight, vertex.weight = groupSize,
                   weight.scale = T, label.edge= F,
                   title.name = paste0("Interaction weights/strength - ", names(object.list)[i]),
                   targets.use = 'Macrophage')
}
par(mfrow = c(1,5), xpd=TRUE)
for (i in 1:5){
  groupSize <- table(object.list[[i]]@meta$CellType)
  netVisual_circle(object.list[[i]]@net$weight, vertex.weight = groupSize,
                   weight.scale = T, label.edge= F,
                   title.name = paste0("Interaction weights/strength - ", names(object.list)[i]),
                   targets.use = 'T_cells')
}
par(mfrow = c(1,5), xpd=TRUE)
for (i in 1:5){
  groupSize <- table(object.list[[i]]@meta$CellType)
  netVisual_circle(object.list[[i]]@net$weight, vertex.weight = groupSize,
                   weight.scale = T, label.edge= F,
                   title.name = paste0("Interaction weights/strength - ", names(object.list)[i]),
                   targets.use = 'B_cells')
}
### 保存大小：15x4/ 20x5(larger)
### 绘制3种类免疫细胞互作图 ###
par(mfrow = c(1,5), xpd=TRUE)
for (i in 1:5){
  groupSize <- table(object.list[[i]]@meta$CellType)
  netVisual_circle(object.list[[i]]@net$weight, vertex.weight = groupSize,
                   weight.scale = T, label.edge= F, show.legend= F,
                   title.name = paste0("Interaction weights/strength - ", names(object.list)[i]),
                   targets.use = 'Macrophage')
}
par(mfrow = c(1,5), xpd=TRUE)
for (i in 1:5){
  groupSize <- table(object.list[[i]]@meta$CellType)
  netVisual_circle(object.list[[i]]@net$weight, vertex.weight = groupSize,
                   weight.scale = T, label.edge= F,label.node = F,     # 取消节点标签
                   title.name = paste0("Interaction weights/strength - ", names(object.list)[i]),
                   targets.use = 'T_cells')
}
par(mfrow = c(1,5), xpd=TRUE)
for (i in 1:5){
  groupSize <- table(object.list[[i]]@meta$CellType)
  netVisual_circle(object.list[[i]]@net$weight, vertex.weight = groupSize,
                   weight.scale = T, label.edge = F,label = F,     # 取消节点标签
                   title.name = paste0("Interaction weights/strength - ", names(object.list)[i]),
                   targets.use = 'B_cells')
}


table(object.list[[2]]@meta$CellType)
levels(object.list[[2]]@meta$CellType)


# 将celltype与新顺序调整至一致
unique(object.list[[2]]@meta$CellType)
object.list[[2]]@meta$CellType <- factor(object.list[[2]]@meta$CellType, 
                                         levels = new_cell_order)
unique(levels(object.list[[2]]@meta$CellType))
