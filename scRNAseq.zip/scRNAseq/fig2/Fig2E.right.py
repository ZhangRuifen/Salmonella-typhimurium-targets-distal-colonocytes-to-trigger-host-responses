import scvelo as scv
import pandas as pd
import numpy as np
import os
adata = scv.read('//d0_Allcelltype_dynamicModel.h5ad')
scv.pp.filter_and_normalize(adata,min_shared_counts=30, n_top_genes=2000)
scv.pp.moments(adata, n_pcs=30, n_neighbors=30)
scv.tl.velocity(adata, mode = "stochastic")
scv.tl.velocity_graph(adata)
scv.pl.velocity_embedding(adata, basis='X_umap', arrow_size=0.05)
ident_colours = {
    "Stem/TA": "#E31A1C",
    "pre_DCC": "#FF7F00",
    "DCC": "#FDBF6F",
    "pre_PCC": "#1F78B4",
    "PCC": "#A6CEE3",
    "Mid_CC": "#FB9A99",
    "Goblet_0": "#777e41",
    "Goblet_1": "#33A02C",
    "Goblet_2": "#B2DF8A",
    "M_cell": "#6A3D9A",
    "EEC": "#e9bc00"
}
scv.pl.velocity_embedding_stream(adata, basis='X_umap',color = "celltype", palette = ident_colours, size = 20,alpha =0.8, save="005_d0_2UMAP_stream.pdf", figsize=(7,7), legend_fontsize = 9, show=False, title='',legend_loc="none", arrow_size=0.05)
scv.pl.velocity_embedding_stream(adata, basis='X_umap', color="celltype", palette = ident_colours, size=20, alpha=0.8, save="005_d0_2UMAP_stream.svg", figsize=(7,7), legend_fontsize=9, show=False, title='',legend_loc="none", arrow_size=0.05)
adata = scv.read('//d1_Allcelltype_dynamicModel.h5ad')
scv.pp.filter_and_normalize(adata,min_shared_counts=30, n_top_genes=2000)
scv.pp.moments(adata, n_pcs=30, n_neighbors=30)
scv.tl.velocity(adata, mode = "stochastic")
scv.tl.velocity_graph(adata)
scv.pl.velocity_embedding(adata, basis='X_umap', arrow_size=0.05)
ident_colours = {
    "Stem/TA": "#E31A1C",
    "pre_DCC": "#FF7F00",
    "DCC": "#FDBF6F",
    "pre_PCC": "#1F78B4",
    "PCC": "#A6CEE3",
    "Mid_CC": "#FB9A99",
    "Goblet_0": "#777e41",
    "Goblet_1": "#33A02C",
    "Goblet_2": "#B2DF8A",
    "M_cell": "#6A3D9A",
    "EEC": "#e9bc00"
}
scv.pl.velocity_embedding_stream(adata, basis='X_umap',color = "celltype", palette = ident_colours, size = 20,alpha =0.8, save="005_d1_2UMAP_stream.pdf", figsize=(7,7), legend_fontsize = 9, show=False, title='',legend_loc="none", arrow_size=0.05)
scv.pl.velocity_embedding_stream(adata, basis='X_umap', color="celltype", palette = ident_colours, size=20, alpha=0.8, save="005_d1_2UMAP_stream.svg", figsize=(7,7), legend_fontsize=9, show=False, title='',legend_loc="none", arrow_size=0.05)
adata = scv.read('//d3_Allcelltype_dynamicModel.h5ad')
scv.pp.filter_and_normalize(adata,min_shared_counts=30, n_top_genes=2000)
scv.pp.moments(adata, n_pcs=30, n_neighbors=30)
scv.tl.velocity(adata, mode = "stochastic")
scv.tl.velocity_graph(adata)
scv.pl.velocity_embedding(adata, basis='X_umap', arrow_size=0.05)
ident_colours = {
    "Stem/TA": "#E31A1C",
    "pre_DCC": "#FF7F00",
    "DCC": "#FDBF6F",
    "pre_PCC": "#1F78B4",
    "PCC": "#A6CEE3",
    "Mid_CC": "#FB9A99",
    "Goblet_0": "#777e41",
    "Goblet_1": "#33A02C",
    "Goblet_2": "#B2DF8A",
    "M_cell": "#6A3D9A",
    "EEC": "#e9bc00"
}
scv.pl.velocity_embedding_stream(adata, basis='X_umap',color = "celltype", palette = ident_colours, size = 20,alpha =0.8, save="005_d3_2UMAP_stream.pdf", figsize=(7,7), legend_fontsize = 9, show=False, title='',legend_loc="none", arrow_size=0.05)
scv.pl.velocity_embedding_stream(adata, basis='X_umap', color="celltype", palette = ident_colours, size=20, alpha=0.8, save="005_d3_2UMAP_stream.svg", figsize=(7,7), legend_fontsize=9, show=False, title='',legend_loc="none", arrow_size=0.05)
adata = scv.read('//d5_Allcelltype_dynamicModel.h5ad')
scv.pp.filter_and_normalize(adata,min_shared_counts=30, n_top_genes=2000)
scv.pp.moments(adata, n_pcs=30, n_neighbors=30)
scv.tl.velocity(adata, mode = "stochastic")
scv.tl.velocity_graph(adata)
scv.pl.velocity_embedding(adata, basis='X_umap', arrow_size=0.05)
ident_colours = {
    "Stem/TA": "#E31A1C",
    "pre_DCC": "#FF7F00",
    "DCC": "#FDBF6F",
    "pre_PCC": "#1F78B4",
    "PCC": "#A6CEE3",
    "Mid_CC": "#FB9A99",
    "Goblet_0": "#777e41",
    "Goblet_1": "#33A02C",
    "Goblet_2": "#B2DF8A",
    "M_cell": "#6A3D9A",
    "EEC": "#e9bc00"
}
scv.pl.velocity_embedding_stream(adata, basis='X_umap',color = "celltype", palette = ident_colours, size = 20,alpha =0.8, save="005_d5_2UMAP_stream.pdf", figsize=(7,7), legend_fontsize = 9, show=False, title='',legend_loc="none", arrow_size=0.05)
scv.pl.velocity_embedding_stream(adata, basis='X_umap', color="celltype", palette = ident_colours, size=20, alpha=0.8, save="005_d5_2UMAP_stream.svg", figsize=(7,7), legend_fontsize=9, show=False, title='',legend_loc="none", arrow_size=0.05)
adata = scv.read('//d7_Allcelltype_dynamicModel.h5ad')
scv.pp.filter_and_normalize(adata,min_shared_counts=30, n_top_genes=2000)
scv.pp.moments(adata, n_pcs=30, n_neighbors=30)
scv.tl.velocity(adata, mode = "stochastic")
scv.tl.velocity_graph(adata)
scv.pl.velocity_embedding(adata, basis='X_umap', arrow_size=0.05)
ident_colours = {
    "Stem/TA": "#E31A1C",
    "pre_DCC": "#FF7F00",
    "DCC": "#FDBF6F",
    "pre_PCC": "#1F78B4",
    "PCC": "#A6CEE3",
    "Mid_CC": "#FB9A99",
    "Goblet_0": "#777e41",
    "Goblet_1": "#33A02C",
    "Goblet_2": "#B2DF8A",
    "M_cell": "#6A3D9A",
    "EEC": "#e9bc00"
}
scv.pl.velocity_embedding_stream(adata, basis='X_umap',color = "celltype", palette = ident_colours, size = 20,alpha =0.8, save="005_d7_2UMAP_stream.pdf", figsize=(7,7), legend_fontsize = 9, show=False, title='',legend_loc="none", arrow_size=0.05)
scv.pl.velocity_embedding_stream(adata, basis='X_umap', color="celltype", palette = ident_colours, size=20, alpha=0.8, save="005_d7_2UMAP_stream.svg", figsize=(7,7), legend_fontsize=9, show=False, title='',legend_loc="none", arrow_size=0.05)

import scvelo as scv
import pandas as pd
import os
adata = scv.read('//d0_Allcelltype_dynamicModel.h5ad')
scv.pp.filter_and_normalize(adata, min_shared_counts=30, n_top_genes=2000)
scv.pp.moments(adata, n_pcs=30, n_neighbors=30)
scv.tl.velocity(adata, mode="stochastic")
scv.tl.velocity_graph(adata)
scv.tl.velocity_confidence(adata)
keys = ['velocity_length', 'velocity_confidence']
scv.pl.scatter(adata, c=keys, cmap='coolwarm', perc=[5, 95])
if 'celltype' in adata.obs.columns:
    df = adata.obs.groupby('celltype')[keys].mean().T
    df.style.background_gradient(cmap='coolwarm', axis=1)
    df.to_csv('d0_velocity_confidence_mean.csv')
else:
    print("没有 'celltype' 列，请检查数据！")

