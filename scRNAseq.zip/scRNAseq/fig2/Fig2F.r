library(Seurat)

rename_Epithelial<-readRDS("D://Epithelial.rds")
genes_to_plot <- c("Top2a","Mki67","Stmn1",
                   "Hspb1","Nccrp1","Hgf",
                   "Ugt2b5","Sult1a1","Otc","Tgm3","Tnni1","Ly6g",
                   "Slc51a","Osr2","Apol10a","Chp2","Pdlim2","Plpp1","Creb3l4","Muc2","Tff3",
                   "Gabrp","Spib","Msln","Chga","Chgb","Neurod1")

# 按照特定的CellType顺序绘制
rename_Epithelial$subCelltype <- factor(rename_Epithelial$subCelltype, 
                                          levels = (c("Stem/TA", "Pre_DCC","Pre_PCC","DCC","PCC","Mid_CC",
                                                      "Goblet_0", "Goblet_1", "Goblet_2","M_cell","EEC")))

col<-c("Stem/TA"="#E31A1C","Pre_DCC"="#FF7F00","DCC"="#FDBF6F","Pre_PCC"="#1F78B4","PCC"= "#A6CEE3" ,"Mid_CC"= "#FB9A99",   
       "Goblet_0"="#777e41", "Goblet_1"="#33A02C", "Goblet_2"= "#B2DF8A",
       "M_cell"="#6A3D9A", "EEC"="#e9bc00")

# 绘制点图
p<-DotPlot(rename_Epithelial, features = genes_to_plot, group.by = "subCelltype") +
  scale_color_gradient(low = "grey", high = "#bf0603") +  # 设置颜色梯度
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +coord_flip()