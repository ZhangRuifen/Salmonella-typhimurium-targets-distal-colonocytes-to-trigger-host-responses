library(DESeq2)
library(ggplot2)
library(org.Mm.eg.db)
library(pheatmap)
library(RColorBrewer)
library(dplyr)
library(clusterProfiler)
library(genefilter)


raw_count <-
  as.matrix(read.table(
    "./result.tsv",
    header = T,
    sep = "\t",
    row.names = 1
  ))


condition <- factor(c("ctrl-1", "ctrl-2", "ctrl-3","D1-1", "D1-2", "D1-3","D3-1", "D3-2", "D3-3", "D5-1", "D5-2", "D5-3", "D7-1", "D7-2", "D7-3",))
group <- as.factor(rep(c("ctrl", "D1", "D3","D5", "D7"), c(3, 3, 3, 3, 3)))
colData <- data.frame(condition, group)


dds <- DESeqDataSetFromMatrix(
  countData = raw_count,
  colData = colData,
  design = ~group
)
dds <- dds[rowSums(counts(dds)) > 1, ] # 过滤low count数据
nrow(dds)

# get different expression genes
dds <- DESeq(dds)
res <- results(dds)

summary(res)
sum(res$padj < 0.05, na.rm = TRUE)
# 提取normalized count matrix
count_r <- counts(dds, normalized = T)
# 合并DESeq2结果和normalized counts数据
resdata <-
  merge(as.data.frame(res),
    as.data.frame(counts(dds, normalize = TRUE)),
    by = "row.names",
    sort = FALSE
  )

# D3 VS CTRL
d3_vs_ctrl_res <- results(dds, contrast = c("group", "D3", "ctrl"))
summary(d3_vs_ctrl_res)
sum(d3_vs_ctrl_res$padj < 0.05, na.rm = TRUE)
d3_vs_ctrl_all <- subset(d3_vs_ctrl_res, padj < 0.05)
d3_vs_ctrl_up <- subset(d3_vs_ctrl_res, padj < 0.05 & log2FoldChange > 1)
d3_vs_ctrl_down <- subset(d3_vs_ctrl_res, padj < 0.05 & log2FoldChange < -1)
dim(d3_vs_ctrl_down)
dim(d3_vs_ctrl_up)
dim(d3_vs_ctrl_all)
gene_id <- bitr(d3_vs_ctrl_all@rownames, fromType = "ENSEMBL", toType = "ENTREZID", OrgDb = "org.Mm.eg.db", drop = FALSE)
go.d3_vs_ctrl <- enrichGO(
  gene_id$ENTREZID,
  OrgDb = "org.Mm.eg.db"
)

kegg.d3_vs_ctrl <- enrichKEGG(
  gene_id$ENTREZID,
  organism = "mmu"
)



go.d3_vs_ctrl.CC <- enrichGO(
  gene_id$ENTREZID,
  OrgDb = "org.Mm.eg.db",
  ont = 'CC'
)


dotplot(go.d3_vs_ctrl, 
        showCategory = 30,
        title="Mum D3 vs ctrl GO",
        font.size = 10)
dotplot(kegg.d3_vs_ctrl, 
        showCategory = 30,
        title="Mum D3 vs ctrl KEGG",
        font.size = 10)
dotplot(go.d3_vs_ctrl.CC, 
        showCategory = 20,
        title=