library(Seurat)
library(ggplot2)
library(png)

####transcriptome score########
#### Read data from level5 ####
object_day <- CreateBmkObject(
  matrix_path = "...",  #Matrix file directory
  png_path = "day0.png",       #Png format image path
  min.cells = 5,       #A gene is not retained until it is expressed in at least n cells, adjustable, default value 5
  min.features = 50,  #A cell has at least n genes to be retained, adjustable, default 50
  spot_radius = 0.004, #Radius of the mapping point, cell segmentation data must be specified
  type = "S1000"       #Data type, must be specified, optional parameters are ‘S1000’, ‘S2000’, ‘S3000’, ‘cell_split’
)

object_day <- NormalizeData(object_day, verbose = FALSE, assay = "Spatial")

#### interesting genes ####
interest_gene <- c("Ifi44l","Trim15","Zbp1","Lbp","Gbp2")
interest_genes <- Reduce(intersect,list(interest_gene,rownames(object_day@assays$Spatial$counts)))

i = 0
for (interest in interest_genes){
  day <- paste0("day",i)
  
  sp_counts <- as_matrix(object_day@assays$Spatial$counts)
  
  expression <- as.data.frame(sp_counts[rownames(sp_counts) %in% interest,])
  colnames(expression) <- "counts"
  expression$spots <- rownames(expression)
  
  coords <- (object_day@images[[1]]@coordinates)
  coords$tissue<- NULL
  coords$imagecol <- NULL
  coords$imagerow <- NULL
  names(coords) <- c("ycoord", "xcoord")
  
  png = readPNG(paste0(day,".png"))
  zoom_scale = cal_zoom_rate(dim(png)[2], dim(png)[1])
  coords = coords %>% mutate(across(c(xcoord,ycoord), ~.x*zoom_scale))
  coords$spots <- rownames(coords)
  
  data <- merge(expression,coords, by = "spots",all.x = TRUE)
  
  ggplot(data,aes(x = xcoord, y = dim(png)[1]-ycoord)) +
    background_image(png)+
    geom_point(size = 0.3, aes(color = counts)) +  
    scale_color_gradientn(colours = c("darkblue","cyan","yellow","red","darkred"),limits = c(0,4), breaks = c(0,2,4)) +  # 自定义图例标签"lightgray","mistyrose","red","darkred"/#"lightgray", "#FFE100", "#F4A63A", "#FF4400", "#B12222"/"lightgray", "#68BF69", "#088C00", "#025939"
    coord_cartesian(xlim = c(0, dim(png)[2]), ylim = c( 0,dim(png)[1]), expand = FALSE)+
    labs(x = "x", y = "y",color = interest) +
    theme(axis.title.x=element_blank(),
          axis.text.x=element_blank(),
          axis.ticks.x=element_blank(),
          axis.title.y=element_blank(),
          axis.text.y=element_blank(),
          axis.ticks.y=element_blank(),
          text = element_text(family = "Helvetica"),
          legend.background = element_blank(),  
          legend.key = element_blank()) + 
    theme_void()
  
  ggsave(filename = paste0(paste("all day5 factor/",interest,day,"ST图.pdf")), width = 6,height = 5)
  
}


#### Functions ####
CreateBmkObject <- function(
    matrix_path,
    png_path,
    spot_radius = NULL,
    min.cells = 5,
    min.features = 100,
    type = NULL
){
  if(is.null(type)){
    stop("If the type parameter is empty, specify the type parameter. The options are 'S1000', 'S2000', 'S3000', 'cell_split'")
  }
  expr <- Seurat::Read10X(matrix_path, cell.column = 1)
  object <- Seurat::CreateSeuratObject(counts = expr,
                                       assay = 'Spatial',
                                       min.cells=min.cells,
                                       min.features=min.features)
  #Image zoom rate
  cal_zoom_rate <- function(width, height, type){
    if(type == "S1000" || type == "S2000" || type == "S3000"){
      std_width = 1000
    }else if(type == "cell_split"){
      std_width = 20000
    }
    std_height = std_width / (46 * 31) * (46 * 36 * sqrt(3) / 2.0)
    if (std_width / std_height > width / height){
      scale = width / std_width
    }
    else{
      scale = height / std_height
    }
    return(scale)
  }
  #read png
  png <- png::readPNG(png_path)
  zoom_scale <-  cal_zoom_rate(dim(png)[2], dim(png)[1], type)
  #read barcode pos file
  ReadBarcodePos <- function(barcode_pos_path){
    barcode_pos <- read.table(gzfile(barcode_pos_path),header = F) %>%
      dplyr::rename(Barcode = V1 , pos_w = V2, pos_h = V3)
    return(barcode_pos)
  }
  #get barcode pos file path
  barcode_pos_path <- paste0(matrix_path,'/barcodes_pos.tsv.gz')
  barcode_pos <- ReadBarcodePos(barcode_pos_path = barcode_pos_path)
  barcode_pos <- barcode_pos %>% dplyr::filter(., Barcode %in% rownames(object@meta.data))
  #make spatial coord file for seurat S4 class
  coord <- data.frame(tissue = 1,
                      row = barcode_pos$pos_h,
                      col = barcode_pos$pos_w,
                      imagerow = barcode_pos$pos_h,
                      imagecol = barcode_pos$pos_w)
  rownames(coord) <- barcode_pos$Barcode
  #spot radius
  if(type == "S1000" || type == "S2000"){
    spot_radius_lib <- c(0.00063, 0.00179, 0.0027, 0.0039, 0.004, 0.0045, 0.005, NA, NA, NA, NA, NA, 0.0120)
  }else if(type == "S3000"){
    spot_radius_lib <- c(0.00015, 0.00075, 0.0018, 0.0026, 0.003, 0.0039, 0.004, NA, 0.005, NA, NA, NA, NA, NA, NA, NA, 0.0120, 0.0120)
  }
  if(is.null(spot_radius)){
    spot_radius <- spot_radius_lib[as.numeric(gsub('L', '', strsplit(tail(strsplit(matrix_path, '/')[[1]],1), '_')[[1]][1]))]
  }else{
    spot_radius = spot_radius
  }
  if(is.null(spot_radius)){
    stop("The spot_radius parameter is null. Please specify the spot_radius parameter!!!")
  }
  #object
  sample1 <-  new(Class = "VisiumV1",
                  image = png,
                  scale.factors = Seurat::scalefactors(zoom_scale, 100, zoom_scale, zoom_scale),
                  coordinates = coord,
                  spot.radius = spot_radius,
                  assay = 'Spatial',
                  key = "sample1_")
  object@images <- list(sample1 = sample1)
  
  return(object)
}

Rcpp::sourceCpp(code='
#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
IntegerMatrix asMatrix(NumericVector rp, 
                       NumericVector cp, 
                       NumericVector z, 
                       int nrows, 
                       int ncols) {
  int k = z.size(); 
  IntegerMatrix mat(nrows, ncols); 
  
  for (int i = 0; i < k; i++) {
    mat(rp[i], cp[i]) = z[i]; 
  }
  
  return mat; 
}')


as_matrix <- function(mat) {
  
  row_pos <- mat@i
  
  col_pos <- findInterval(seq(mat@x) - 1, mat@p[-1])
  
  tmp <- asMatrix(
    rp = row_pos,    
    cp = col_pos,     
    z = mat@x,       
    nrows = mat@Dim[1], 
    ncols = mat@Dim[2]  
  )
  
  row.names(tmp) <- mat@Dimnames[[1]]
  colnames(tmp) <- mat@Dimnames[[2]]
  
  
  return(tmp)
}

#  Calculate coordinate scaling
cal_zoom_rate <- function(width, height){  
  std_width = 1000 
  std_height = std_width / (46 * 31) * (46 * 36 * sqrt(3) / 2.0)  
  
  if (std_width / std_height > width / height){      
    scale = width / std_width    
  }    
  else{      
    scale = height / std_height    
  }    
  return(scale)
}
