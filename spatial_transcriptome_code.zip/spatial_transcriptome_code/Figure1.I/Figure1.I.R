library(Seurat)
library(ggplot2)
library(patchwork)
library(dplyr)

#### 1.1.Define a function ####
CreateBmkObject <- function(
    matrix_path,
    png_path,
    spot_radius = NULL,
    min.cells = 5,
    min.features = 100,
    type = NULL
){
  if(is.null(type)){
    stop("If the type parameter is empty, specify the type parameter. The options are 'S1000', 'S2000', 'S3000', 'cell_split'")
  }
  expr <- Seurat::Read10X(matrix_path, cell.column = 1)
  object <- Seurat::CreateSeuratObject(counts = expr,
                                       assay = 'Spatial',
                                       min.cells=min.cells,
                                       min.features=min.features)
  #Image zoom rate
  cal_zoom_rate <- function(width, height, type){
    if(type == "S1000" || type == "S2000" || type == "S3000"){
      std_width = 1000
    }else if(type == "cell_split"){
      std_width = 20000
    }
    std_height = std_width / (46 * 31) * (46 * 36 * sqrt(3) / 2.0)
    if (std_width / std_height > width / height){
      scale = width / std_width
    }
    else{
      scale = height / std_height
    }
    return(scale)
  }
  #read png
  png <- png::readPNG(png_path)
  zoom_scale <-  cal_zoom_rate(dim(png)[2], dim(png)[1], type)
  #read barcode pos file
  ReadBarcodePos <- function(barcode_pos_path){
    barcode_pos <- read.table(gzfile(barcode_pos_path),header = F) %>%
      dplyr::rename(Barcode = V1 , pos_w = V2, pos_h = V3)
    return(barcode_pos)
  }
  #get barcode pos file path
  barcode_pos_path <- paste0(matrix_path,'/barcodes_pos.tsv.gz')
  barcode_pos <- ReadBarcodePos(barcode_pos_path = barcode_pos_path)
  barcode_pos <- barcode_pos %>% dplyr::filter(., Barcode %in% rownames(object@meta.data))
  #make spatial coord file for seurat S4 class
  coord <- data.frame(tissue = 1,
                      row = barcode_pos$pos_h,
                      col = barcode_pos$pos_w,
                      imagerow = barcode_pos$pos_h,
                      imagecol = barcode_pos$pos_w)
  rownames(coord) <- barcode_pos$Barcode
  #spot radius
  if(type == "S1000" || type == "S2000"){
    spot_radius_lib <- c(0.00063, 0.00179, 0.0027, 0.0039, 0.004, 0.0045, 0.005, NA, NA, NA, NA, NA, 0.0120)
  }else if(type == "S3000"){
    spot_radius_lib <- c(0.00015, 0.00075, 0.0018, 0.0026, 0.003, 0.0039, 0.004, NA, 0.005, NA, NA, NA, NA, NA, NA, NA, 0.0120, 0.0120)
  }
  if(is.null(spot_radius)){
    spot_radius <- spot_radius_lib[as.numeric(gsub('L', '', strsplit(tail(strsplit(matrix_path, '/')[[1]],1), '_')[[1]][1]))]
  }else{
    spot_radius = spot_radius
  }
  if(is.null(spot_radius)){
    stop("The spot_radius parameter is null. Please specify the spot_radius parameter!!!")
  }
  #object
  sample1 <-  new(Class = "VisiumV1",
                  image = png,
                  scale.factors = Seurat::scalefactors(zoom_scale, 100, zoom_scale, zoom_scale),
                  coordinates = coord,
                  spot.radius = spot_radius,
                  assay = 'Spatial',
                  key = "sample1_")
  object@images <- list(sample1 = sample1)
  
  return(object)
}



#### 1.2.Read data from level5 ####
object_day0 <- CreateBmkObject(
  matrix_path = "...",  #Matrix file directory
  png_path = "...",       #Png format image path
  min.cells = 5,       #A gene is not retained until it is expressed in at least n cells, adjustable, default value 5
  min.features = 50,  #A cell has at least n genes to be retained, adjustable, default 50
  spot_radius = 0.004, #Radius of the mapping point, cell segmentation data must be specified
  type = "S1000"       #Data type, must be specified, optional parameters are ‘S1000’, ‘S2000’, ‘S3000’, ‘cell_split’
)

object_day0 <- NormalizeData(object_day0, verbose = FALSE, assay = "Spatial")
object_day1 <- NormalizeData(object_day1, verbose = FALSE, assay = "Spatial")
object_day3 <- NormalizeData(object_day3, verbose = FALSE, assay = "Spatial")
object_day5 <- NormalizeData(object_day5, verbose = FALSE, assay = "Spatial")

# Integrate all the objects
combined_object <- merge(object_day0, y = c(object_day1, object_day3, object_day5), add.cell.ids = c("day0", "day1", "day3", "day5"))

# Add grouping labels to day columns
combined_object$day <- gsub("_.*", "", colnames(combined_object))

#Genes of interest
interest_gene <- read.csv("1.KEGG_salmonella_enriched_all_ID.csv")
interest_gene <- interest_gene$Gene

####1.3 SpatialFeaturePlot locate####

day = c("day0","day1","day3","day5")
for(j in day){
  object_day<-subset(combined_object,subset = day ==j)
  
  #Extract common parts of the interest_gene and existing genes
  own_gene <- rownames(object_day@assays$Spatial$data)
  gene_set <- Reduce(intersect,list(interest_gene,own_gene))
  gene_set <- as.data.frame(gene_set)
  gene_set <- as.list(gene_set)
  
  roi_means <- AddModuleScore(
    object = object_day,
    features = gene_set,
    ctrl = 60,
    name = "interest_gene")
  
  p2 <- SpatialFeaturePlot(roi_means, features = "interest_gene1", pt.size.factor = 8) + 
    theme(legend.position = "right")+
    ggplot2::scale_fill_gradientn(
      colors = c("darkblue","cyan","yellow","red","darkred"),  
      limits = c(0, 0.3),               
      breaks = c(0, 0.1,0.2,0.3), 
      name = "Salmonella infection", 
      oob = scales::squish                
    )
  p2
  
}