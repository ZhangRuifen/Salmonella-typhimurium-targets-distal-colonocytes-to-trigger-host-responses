library(magick)
library(Matrix)
library(spacexr)
library(png)
library(imager)
library(STutility)
library(zeallot)
library(magrittr)
library(dplyr)
library(dbscan)
library(ggplot2)
library(cowplot)
library(egg)
library(ggpubr)

##########Annotation information##########
#cell-splited data
object_day <- readRDS("d1.cell.single_seruat.Rds")
object_day <- NormalizeData(object_day, verbose = FALSE, assay = "Spatial")

#Importing spatial information
coords <- (object_day@images[[1]]@coordinates)
coords$tissue<- NULL
coords$imagecol <- NULL
coords$imagerow <- NULL
names(coords) <- c("xcoord", "ycoord")

sp_counts <- as_matrix(object_day@assays$Spatial$counts)

sp_nUMI <- colSums(sp_counts)
puck <- SpatialRNA(coords, sp_counts, sp_nUMI)

#Implementing RCTD
myRCTD <- create.RCTD(puck, reference, max_cores = 8)
myRCTD <- run.RCTD(myRCTD, doublet_mode = 'doublet')

#Reading RCTD files
results <- myRCTD@results
results_df <- results$results_df
barcodes = rownames(results_df[results_df$spot_class != "reject" & puck@nUMI >= 1,])
my_table = puck@coords[barcodes,]
colnames(my_table) <- c("y","x")
my_table$class = results_df[barcodes,]$first_type
my_table =  na.omit(my_table)

png = readPNG("day1.png")
zoom_scale = cal_zoom_rate(dim(png)[2], dim(png)[1])
my_table = my_table %>% mutate(across(c(x,y), ~.x*zoom_scale))

##########Expanded intestinal transcriptome##########
# Extract the baseLayer
base.layers <- c("layer1.png",
                 "layer2.png",
                 "layer3.png",
                 "layer4.png",
                 "layer5.png")
xy.all <- do.call(rbind, lapply(seq_along(base.layers), function(i) {
  im <- base.layers[[i]]
  x <- image_read(im) %>% as.raster() 
  xy <- as.data.frame(which( x == "#000000ff", arr.ind = T))#000000ff
  xy$layer <- i
  return(xy)
}))

ggplot(xy.all,aes(x = col,y = dim(png)[1]-row))+
  geom_point(size = 0.1, color = "black") +
  theme_void()


# Calculate the closest distance from Visium spots to the datum (outline) and connect each spot to the closest datum
set1 = my_table[,c("x","y")]#Coordinates of Visium spots
set2 = xy.all[, 2:1]#Coordinates of points on the baseline

mindists <- apply(set1, 1, function(x) {
  which.min(sqrt(colSums((t(set2) - x)^2)))
})

gg <- cbind(xy.all[mindists, ], set1)

ggplot() +
  geom_segment(data = gg, aes(x = col, xend = x, y = row, yend = y)) +
  scale_y_reverse()

xy.all$id <- paste0("id", 1:nrow(xy.all))
rownames(xy.all) <- xy.all$id

y <- dbscan::kNN(x = xy.all[, 1:2], k = 5, sort = FALSE)

adj <- rbind(data.frame(from = xy.all$id, to = xy.all$id[y$id[, 1]], d = y$dist[, 1]),
             data.frame(from = xy.all$id, to = xy.all$id[y$id[, 2]], d = y$dist[, 2]),
             data.frame(from = xy.all$id, to = xy.all$id[y$id[, 3]], d = y$dist[, 3]),
             data.frame(from = xy.all$id, to = xy.all$id[y$id[, 4]], d = y$dist[, 4]),
             data.frame(from = xy.all$id, to = xy.all$id[y$id[, 5]], d = y$dist[, 5]))

adj.mat <- reshape2::acast(data = adj, formula = from ~ to, value.var = "d", fill = 0)

ig <- igraph::graph_from_adjacency_matrix(adj.mat)

end.points <- names(sort(rowMeans(y$dist), decreasing = TRUE))[1:5]


gg <- xy.all
gg$hl <- ifelse(gg$id %in% end.points, match(gg$id, end.points), "")
ggplot() +
  geom_point(data = gg, aes(col, row),size = 0.1) +
  geom_text(data = gg, aes(col, row, label = hl)) +
  theme_void()

#Define the shortest path
sp1 <- igraph::shortest_paths(graph = ig,
                              from = end.points[3],
                              to = end.points[1])
sp2 <- igraph::shortest_paths(graph = ig,
                              from = end.points[2],
                              to = end.points[5])
setdiff(end.points, sp2$vpath[[1]])
# Get the nodes of both paths
path1 <- sp1$vpath[[1]]  
path2 <- sp2$vpath[[1]] 

# Merge path
merged_path <- c(path1, path2)

#Reorder node boxes xy.all
xy.all <- xy.all[names(merged_path), ]
xy.all$ord <- 1:nrow(xy.all)

ggplot() +
  geom_point(data = xy.all, aes(col, dim(png)[1] - row)) +
  geom_label(data = xy.all[seq(1, nrow(xy.all), length.out = 40), ], aes(col, dim(png)[1] - row, label = ord)) +
  theme_void()

#Determine the match between Visium Spots and Base Layer
adjust.coords <- function(x, y, P){
  avg <- c(mean(c(x[1], y[1])), mean(c(x[2], y[2])))
  df <- (P - avg)
  x_new <- x - df
  y_new <- y - df
  return(c(x_new, y_new))
} 
sider <- function(x, y, P) {
  (P[1] - x[1])*(y[2] - x[2]) - (P[2] - x[2])*(y[1] - x[1])
}
angle <- function(x, y, P){
  Angle(A = P, B = c(mean(c(x[1], y[1])), mean(c(x[2], y[2]))), C = y)
}
sign_angle <- function(x, y, P) {
  angle(x, y, P)*sign(sider(x, y, P))
}
expand.range <- function(x, exp.factor = 5, maxval = 1e4) {
  y <- c(max(1, x - exp.factor), min(x + exp.factor, maxval))
  return(y)
}

# calculates the correspondence of each point with respect to the Base Layer
set1 = my_table[,c("x","y")]
set2 = xy.all[, 2:1]
dists <- as.matrix(apply(set1, 1, function(x) {
  sqrt(colSums((t(set2) - x)^2))
}))

spots.list <- do.call(rbind, pbmcapply::pbmclapply(colnames(dists), function(s) {
  P <- set1[s, ]
  dists.subset <- dists[, s]
  if(s == 4)
    dists.subset <- dists.subset[dists.subset < 300]
  else
    dists.subset <- dists.subset[dists.subset < 80]
  checks <- vapply(names(dists.subset), function(b) {
    xs <- expand.range(xy.all[b, "ord"] %>% as.numeric(), 
                       exp.factor = 5, maxval = nrow(xy.all))
    xs <- xy.all[xs, ]
    ls <- adjust.coords(x = as.numeric(xs[1, 2:1]), y = as.numeric(xs[2, 2:1]), P = as.numeric(P))
    x <- ls[1:2]; y <- ls[3:4]
    y <- sign_angle(x = x, y = y, P = as.numeric(P))
    -45 > y && y > -135
  },logical(1))  
  if (sum(checks) > 0) {
    bl.subset <- dists.subset[checks]
    return(data.frame(dist = bl.subset, id = names(bl.subset), spot = s))
  } else {return(NULL)}
}))

# Select the closest base layer point for each spot
spots.summarized <- spots.list %>%
  group_by(spot) %>%
  top_n(n = 1, wt = -dist)

g <- merge(xy.all, spots.summarized, by = "id", all = T)
g <- cbind(g, set1[g$spot, ])
g <- na.omit(g)

ftrs <- c("DCC","Mid_CC","PCC")

table <- my_table[,3, drop = FALSE]
table <- subset(table, class %in% ftrs)
for(i in ftrs){
  row <- which(table$class == i)
  table[[i]] <- 0
  table[[i]][row] <- 1
}
table$class <- NULL
table$spot <- rownames(table)
ggs <-  merge(g, table, by = "spot",all.x = TRUE)
ggs[is.na(ggs)] <- 0


##########DC,MC,PC segmentation##########
list <- 1
i= 1
for (i in list){
  
  day <- paste0("day",i)
  sp_counts <- as_matrix(object_day@assays$Spatial$counts)
  
  ggs_ord <- ggs %>%
    arrange(ord)
  
  n <- nrow(ggs_ord)
  
  for (i in seq(1, n, by = 100)) {
    end_row <- min(i + 99, n)
    
    chunk <- ggs_ord[i:end_row, ]
    
    dcc_count <- sum(chunk$DCC == 1)
    mid_cc_count <- sum(chunk$Mid_CC == 1)
    pcc_count <- sum(chunk$PCC == 1)
    
    counts <- c(PCC = pcc_count, Mid_CC = mid_cc_count,DCC = dcc_count )
    
    max_count <- max(counts)
    if (max_count != 0){
      max_col <- names(counts)[which.max(counts)]
    }else{
      chunk$class <- "others"
    }
    chunk$class <- max_col
    
    ggs_ord$class[ggs_ord$id %in% chunk$id] <- chunk$class
  }

  plotlist <- lapply(ftrs, function(ftr) {
    p1 <- ggplot(ggs_ord, aes_string("ord", "dist", z = paste0("`", ftr, "`"),
                                     color = paste0("`", ftr, "`"))) +
      stat_summary_hex(binwidth = c(20, 3), color = NA) +
      scale_fill_gradientn(colours = c("lightgray", "mistyrose", "red", "darkred"), limits = c(0,1)) +
      theme_void() +
      theme(plot.title = element_text(size = 12 ,hjust = 0.5),
            plot.margin = unit(c(0.1, 0.2, 0.1, 0), units = "cm")) +
      labs(x = "position along colon", y = "thickness", title = paste("day",i,ftr,sep = "_")) +
      guides(fill = guide_colourbar(barwidth = 1, barheight = 4))
    return(p1)
  })
  
  p1 <- egg::ggarrange(plots = plotlist, ncol = 1)
  p1
  
  #ST plot
  png <- readPNG("day1.png")
  ggplot(ggs_ord,aes(x = x,y = dim(png)[1]-y,color= class)) +
    geom_point(size = 0.5)+
    theme_classic()
  
  
  #################Day1 data preprocessing#####################
  ord_diff <- diff(ggs_ord$ord)

  large_diff_index <- which(ord_diff > 40)

  result <- ggs_ord[c(large_diff_index, large_diff_index + 1), ]
  order <- as.numeric(result$ord[2])
  
  ggs_ord$class[ggs_ord$class == "DCC" & ggs_ord$ord<order] <- "Mid_CC"
  
  #ST plot check
  png <- readPNG("day1.png")
  ggplot(ggs_ord,aes(x = x,y = dim(png)[1]-y,color= class)) +
    geom_point(size = 0.5)+
    theme_classic()
  
  
  DCC_min <- ggs_ord %>%
    filter(class == "DCC") %>%
    slice_min(ord)
  order <- as.numeric(DCC_min$ord[1])
  
  ggs_ord$class[ggs_ord$class == "Mid_CC" & ggs_ord$ord>order] <- "DCC"
  
  #ST plot check
  png <- readPNG("day1.png")
  ggplot(ggs_ord,aes(x = x,y = dim(png)[1]-y,color= class)) +
    geom_point(size = 0.5)+
    theme_classic()
  
  
  ggs_Pcc <- ggs_ord %>%
    filter(class == "PCC") %>% 
    arrange(order)  
  
  result <- ggs_Pcc %>%
    mutate(order_diff = c(NA, diff(ord))) %>%  
    filter(order_diff > 50) 
  order <- as.numeric(result$ord[1]) -10
  ggs_ord$class[ggs_ord$class == "PCC" & ggs_ord$ord>order] <- "Mid_CC"
  
  #ST plot check
  png <- readPNG("day1.png")
  ggplot(ggs_ord,aes(x = x,y = dim(png)[1]-y,color= class)) +
    geom_point(size = 0.5)+
    theme_classic()
  
  
  PCC_max <- ggs_ord %>%
    filter(class == "PCC") %>%
    slice_max(ord)
  
  order <- as.numeric(PCC_max$ord[1])
  
  ggs_ord$class[ggs_ord$class == "Mid_CC" & ggs_ord$ord<order] <- "PCC"
  

  #ST plot check
  png <- readPNG("day1.png")
  ggplot(ggs_ord,aes(x = x,y = dim(png)[1]-y,color= class)) +
    geom_point(size = 0.5)+
    coord_cartesian(xlim = c(0, dim(png)[2]), ylim = c( 0,dim(png)[1]), expand = FALSE)+
    labs(x = "x", y = "y",color = "class") +
    theme(axis.title.x=element_blank(),
          axis.text.x=element_blank(),
          axis.ticks.x=element_blank(), 
          axis.title.y=element_blank(),
          axis.text.y=element_blank(),
          axis.ticks.y=element_blank(),
          legend.key = element_blank(),
          text = element_text(family = "Helvetica"))+
    scale_color_manual(
      values = c("DCC" = "#F8766D", "Mid_CC" = "#00BA38", "PCC" = "#619CFF"), 
      labels = c("Distal Colonocyte", "Middle Colonocyte", "Proximal Colonocyte") 
    )+
    theme_void()+
    guides(
      color = guide_legend(override.aes = list(size = 2.5)))

  
  
  #####################Quantification of gene pathways of interest##########################
  geneset_names <- c("Antigen Presentation","IL17_signaling_pathway","TNF_signaling_pathway","Th1_and_Th2_cell_differentiation",
                     "Neutrophil_extracellular_trap_formation","Cell_adhesion_molecules")
  
  geneset_names <- c("Th1_and_Th2_cell_differentiation")
  
  
  counts = 1
  for(gene_name in geneset_names){
    if(gene_name == "Antigen Presentation"){
      #Antigen Presentation
      interest_gene<-c("B2m","Cd8a","Psme1","H2-DMb1","Tap1","H2-Ab1","H2-Aa","H2-Eb1","H2-T23","H2-T22","H2-K1","H2-D1","H2-T10","Cd74")
    }else if(gene_name == "IL17_signaling_pathway"){
      #IL17_signaling_pathway
      interest_gene <- read.csv("IL17_signaling_pathway.csv")
      interest_gene <- interest_gene$IL17_signaling_pathway
    }else if(gene_name == "TNF_signaling_pathway"){
      #TNF_signaling_pathway
      interest_gene <- read.csv("TNF_signaling_pathway.csv")
      interest_gene <- interest_gene$TNF_signaling_pathway
    }else if(gene_name == "Neutrophil_extracellular_trap_formation"){
      #Neutrophil_extracellular_trap_formation
      interest_gene <- read.csv("Neutrophil_extracellular_trap_formation.csv")
      interest_gene <- interest_gene$Neutrophil_extracellular_trap_formation
    }else if(gene_name == "Cell_adhesion_molecules"){
      #Cell_adhesion_molecules
      interest_gene <- read.csv("Cell_adhesion_molecules.csv")
      interest_gene <- interest_gene$Cell_adhesion_molecules
    }else{
      #Th1_and_Th2_cell_differentiation
      interest_gene <- read.csv("Th1_and_Th2_cell_differentiation.csv")
      interest_gene <- interest_gene$Th1_and_Th2_cell_differentiation
    }
    
    set_counts <- sp_counts[rownames(sp_counts) %in% interest_gene,]
    set_nUMI <- as.data.frame(colSums(set_counts))
    set_nUMI$spot <- rownames(set_nUMI)
    colnames(set_nUMI)[1] <- 'genesUMI'
    
    ggs_new <-  base::merge(ggs_ord, set_nUMI, by = "spot",all.x = TRUE)
    ggs_new$genesUMI.x <- NULL
    colnames(ggs_new)[colnames(ggs_new) == "genesUMI.y"] <- "genesUMI"
    ggs_new[is.na(ggs_new)] <- 0
    
    mean_cell_expression <- ggs_new %>%
      group_by(class) %>%
      summarize(cell_mean = mean(genesUMI, na.rm = TRUE))  # 忽略 NA 值
    ggs_mean <- mean_cell_expression[order(mean_cell_expression$cell_mean, decreasing = TRUE), ]
    ggs_new$class <- factor(ggs_new$class, levels = ggs_mean$class)
    
    col3 = c("DCC" = "#70e014",
             "Mid_CC" = "#a663cc",
             "PCC" = "#15821E") 
    
    #Violin plot visualisation
    ggplot(ggs_new, aes(x = class, y = genesUMI)) + 
      scale_color_manual(values  = col3)+
      scale_fill_manual(values  = col3)+
      geom_violin(scale = "width",width = 0.4,trim = FALSE,aes(fill = class, colour = class),alpha = 0.3) + #绘制小提琴图，设置填充色 
      geom_point(aes(colour = class) ,size = 0.1 , position = position_jitter(0.05)) +
      geom_boxplot(aes(colour = class) ,width = 0.08 , outlier.shape = NA) + 
      stat_summary(fun = mean,geom = "point", size = 2, color = "#B8860B") + 
      stat_compare_means(method = "t.test", label = "p.signif", paired = FALSE,
                         comparisons = list(c("DCC", "Mid_CC"),c("DCC", "PCC")))+
      scale_x_discrete(labels = c("DCC" = "DC", "Mid_CC" = "MC", "PCC" = "PC")) +  
      labs(x = " ", y = "Mean Counts", title =  paste0("Day1 ",gene_name)) +
      theme_classic()+  
      theme(
        legend.position="none",
        plot.title = element_text(size=10,face = "bold",hjust = 0.5),
        axis.title.x = element_text(size = 8),   
        axis.title.y = element_text(size = 8), 
        axis.text.x = element_text(size = 8),   
        axis.text.y = element_text(size = 8),   
      ) 
  }
  
  ####################Quantification of Top50 gene expression#########################
  interest_genes <- c("Cyp2c55","Gsdmc3","Gsdmc4","Gsdmc2","Car3","Cyp2e1","Cfd","Reg3g","Reg3b","Mmp7","Ltf","Ly6d","Serpina3n",
                      "Pla2g2a","Cstdc5","Cstdc4","Wfdc21","Cxcl2","Mmp3","Lbp","Chil1","S100a8","S100a9","Chil3","Mmp8","Lcn2","Ngp",
                      "Acod1","Clec4e","F10","Fpr1","Fpr2","Cxcl5","Lrg1","Clca4b","Hp","Saa3")
  interest_genes <- Reduce(intersect, list(interest_genes, rownames(object_day@assays$Spatial$data)))
  
  for (interest_gene in interest_genes){
    gene_name <- interest_gene
    
    set_counts <- sp_counts[rownames(sp_counts) %in% interest_gene,]
    set_nUMI <- as.data.frame(set_counts)
    
    set_nUMI$spot <- rownames(set_nUMI)
    colnames(set_nUMI)[1] <- 'genesUMI'
    
    ggs_new <-  base::merge(ggs_ord, set_nUMI, by = "spot",all.x = TRUE)
    ggs_new$genesUMI.x <- NULL
    colnames(ggs_new)[colnames(ggs_new) == "genesUMI.y"] <- "genesUMI"
    ggs_new[is.na(ggs_new)] <- 0

    mean_cell_expression <- ggs_new %>%
      group_by(class) %>%
      summarize(cell_mean = mean(genesUMI, na.rm = TRUE))  # 忽略 NA 值
    ggs_mean <- mean_cell_expression[order(mean_cell_expression$cell_mean, decreasing = TRUE), ]
    ggs_new$class <- factor(ggs_new$class, levels = ggs_mean$class)
    
    col3 = c("DCC" = "#70e014",
             "Mid_CC" = "#a663cc",
             "PCC" = "#15821E") 
    
    #Violin plot visualisation
    ggplot(ggs_new, aes(x = class, y = genesUMI)) + 
      scale_color_manual(values  = col3)+
      scale_fill_manual(values  = col3)+
      geom_violin(scale = "width",width = 0.4, trim = FALSE,aes(fill = class, colour = class),alpha = 0.3) + #绘制小提琴图，设置填充色 
      geom_point(aes(colour = class) ,size = 0.1 , position = position_jitter(0.05)) +
      geom_boxplot(aes(colour = class) ,width = 0.08 , outlier.shape = NA) + 
      stat_summary(fun = mean,geom = "point", size = 2, color = "#B8860B") +
      stat_compare_means(method = "t.test", label = "p.signif", paired = FALSE,
                         comparisons = list(c("DCC", "Mid_CC"),c("DCC", "PCC")))+
      scale_x_discrete(labels = c("DCC" = "DC", "Mid_CC" = "MC", "PCC" = "PC")) +  
      labs(x = " ", y = "Mean Counts", title =  paste0("Day1 ",gene_name)) +
      theme_classic()+  
      theme(
        legend.position="none",
        plot.title = element_text(size=10,face = "bold",hjust = 0.5),
        axis.title.x = element_text(size = 8),  
        axis.title.y = element_text(size = 8),   
        axis.text.x = element_text(size = 8),   
        axis.text.y = element_text(size = 8),    
      ) 
  }
  
  
#### Functions ####
CreateBmkObject <- function(
  matrix_path,
  png_path,
  spot_radius = NULL,
  min.cells = 5,
  min.features = 100,
  type = NULL
){
  if(is.null(type)){
    stop("If the type parameter is empty, specify the type parameter. The options are 'S1000', 'S2000', 'S3000', 'cell_split'")
  }
  expr <- Seurat::Read10X(matrix_path, cell.column = 1)
  object <- Seurat::CreateSeuratObject(counts = expr,
                                       assay = 'Spatial',
                                       min.cells=min.cells,
                                       min.features=min.features)
  #Image zoom rate
  cal_zoom_rate <- function(width, height, type){
    if(type == "S1000" || type == "S2000" || type == "S3000"){
      std_width = 1000
    }else if(type == "cell_split"){
      std_width = 20000
    }
    std_height = std_width / (46 * 31) * (46 * 36 * sqrt(3) / 2.0)
    if (std_width / std_height > width / height){
      scale = width / std_width
    }
    else{
      scale = height / std_height
    }
    return(scale)
  }
  #read png
  png <- png::readPNG(png_path)
  zoom_scale <-  cal_zoom_rate(dim(png)[2], dim(png)[1], type)
  #read barcode pos file
  ReadBarcodePos <- function(barcode_pos_path){
    barcode_pos <- read.table(gzfile(barcode_pos_path),header = F) %>%
      dplyr::rename(Barcode = V1 , pos_w = V2, pos_h = V3)
    return(barcode_pos)
  }
  #get barcode pos file path
  barcode_pos_path <- paste0(matrix_path,'/barcodes_pos.tsv.gz')
  barcode_pos <- ReadBarcodePos(barcode_pos_path = barcode_pos_path)
  barcode_pos <- barcode_pos %>% dplyr::filter(., Barcode %in% rownames(object@meta.data))
  #make spatial coord file for seurat S4 class
  coord <- data.frame(tissue = 1,
                      row = barcode_pos$pos_h,
                      col = barcode_pos$pos_w,
                      imagerow = barcode_pos$pos_h,
                      imagecol = barcode_pos$pos_w)
  rownames(coord) <- barcode_pos$Barcode
  #spot radius
  if(type == "S1000" || type == "S2000"){
    spot_radius_lib <- c(0.00063, 0.00179, 0.0027, 0.0039, 0.004, 0.0045, 0.005, NA, NA, NA, NA, NA, 0.0120)
  }else if(type == "S3000"){
    spot_radius_lib <- c(0.00015, 0.00075, 0.0018, 0.0026, 0.003, 0.0039, 0.004, NA, 0.005, NA, NA, NA, NA, NA, NA, NA, 0.0120, 0.0120)
  }
  if(is.null(spot_radius)){
    spot_radius <- spot_radius_lib[as.numeric(gsub('L', '', strsplit(tail(strsplit(matrix_path, '/')[[1]],1), '_')[[1]][1]))]
  }else{
    spot_radius = spot_radius
  }
  if(is.null(spot_radius)){
    stop("The spot_radius parameter is null. Please specify the spot_radius parameter!!!")
  }
  #object
  sample1 <-  new(Class = "VisiumV1",
                  image = png,
                  scale.factors = Seurat::scalefactors(zoom_scale, 100, zoom_scale, zoom_scale),
                  coordinates = coord,
                  spot.radius = spot_radius,
                  assay = 'Spatial',
                  key = "sample1_")
  object@images <- list(sample1 = sample1)
  
  return(object)
}

Rcpp::sourceCpp(code='
#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
IntegerMatrix asMatrix(NumericVector rp, 
                     NumericVector cp, 
                     NumericVector z, 
                     int nrows, 
                     int ncols) {
int k = z.size(); 
IntegerMatrix mat(nrows, ncols); 

for (int i = 0; i < k; i++) {
  mat(rp[i], cp[i]) = z[i]; 
}

return mat; 
}')


as_matrix <- function(mat) {
  
  row_pos <- mat@i
  
  col_pos <- findInterval(seq(mat@x) - 1, mat@p[-1])
  
  tmp <- asMatrix(
    rp = row_pos,    
    cp = col_pos,     
    z = mat@x,       
    nrows = mat@Dim[1], 
    ncols = mat@Dim[2]  
  )
  
  row.names(tmp) <- mat@Dimnames[[1]]
  colnames(tmp) <- mat@Dimnames[[2]]
  
  
  return(tmp)
}

#  Calculate coordinate scaling
cal_zoom_rate <- function(width, height){  
  std_width = 20000 
  std_height = std_width / (46 * 31) * (46 * 36 * sqrt(3) / 2.0)  
  
  if (std_width / std_height > width / height){      
    scale = width / std_width    
  }    
  else{      
    scale = height / std_height    
  }    
  return(scale)
}
