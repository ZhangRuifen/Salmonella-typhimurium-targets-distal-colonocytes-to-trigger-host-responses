library(Seurat)
library(tidyverse)
library(Matrix)
library(spacexr)
library(ggplot2)
library(ggpubr)
library(gridExtra)
library(reshape2)
library(readr)
library(Seurat)
library(config)
library(ggpubr)
library(gridExtra)
library(reshape2)
library(png)
library(patchwork)


Rcpp::sourceCpp(code='
#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
IntegerMatrix asMatrix(NumericVector rp, 
                       NumericVector cp, 
                       NumericVector z, 
                       int nrows, 
                       int ncols) {
  int k = z.size(); 
  IntegerMatrix mat(nrows, ncols); 
  
  for (int i = 0; i < k; i++) {
    mat(rp[i], cp[i]) = z[i]; 
  }
  
  return mat; 
}')


as_matrix <- function(mat) {
  
  row_pos <- mat@i
  
  col_pos <- findInterval(seq(mat@x) - 1, mat@p[-1])
  
  tmp <- asMatrix(
    rp = row_pos,    
    cp = col_pos,     
    z = mat@x,       
    nrows = mat@Dim[1], 
    ncols = mat@Dim[2]  
  )
  
  row.names(tmp) <- mat@Dimnames[[1]]
  colnames(tmp) <- mat@Dimnames[[2]]
  
  
  return(tmp)
}


#Importing single-cell data
sc_data <- readRDS("...")
sc_counts <- as_matrix(sc_data@assays$RNA$counts)
sc_nUMI = colSums(sc_counts)
cellType=sc_data@meta.data %>% select(., CellType) %>% rownames_to_column(.,var = "Barcode")
names(cellType) = c('barcode', 'cell_type')

cellType$cell_type<-as.factor(cellType$cell_type)
cellType<-cellType %>% filter(cell_type %in% names(table(cellType$cell_type)[table(cellType$cell_type)>25]))
cellType$cell_type=as.character(cellType$cell_type)

cell_types = cellType$cell_type
names(cell_types) <- cellType$barcode
cell_types = as.factor(cell_types)

levels(cell_types) <- gsub("/", "_", levels(cell_types))

sc_counts<-sc_counts[,which(colnames(sc_counts)%in%cellType$barcode)]
sc_nUMI<-sc_nUMI[cellType$barcode]

#Building Reference Sets
reference = Reference(sc_counts, cell_types, sc_nUMI)

#Importing spatial information
#cell-splited data
object_day <- readRDS("d0.cell.single_seruat.Rds")

coords <- (object_day@images[[1]]@coordinates)
coords$tissue<- NULL
coords$imagecol <- NULL
coords$imagerow <- NULL
names(coords) <- c("xcoord", "ycoord")

sp_counts <- as_matrix(object_day@assays$Spatial$counts)

sp_nUMI <- colSums(sp_counts)
puck <- SpatialRNA(coords, sp_counts, sp_nUMI)

#Implementing RCTD
myRCTD <- create.RCTD(puck, reference, max_cores = 8)
myRCTD <- run.RCTD(myRCTD, doublet_mode = 'doublet')

#Reading RCTD files
results <- myRCTD@results
results_df <- results$results_df
barcodes = rownames(results_df[results_df$spot_class != "reject" & puck@nUMI >= 1,])
my_table = puck@coords[barcodes,]
colnames(my_table) <- c("y","x")
my_table$class = results_df[barcodes,]$first_type
my_table =  na.omit(my_table)

# Calculate coordinate scaling
cal_zoom_rate <- function(width, height){  
  std_width = 20000 
  std_height = std_width / (46 * 31) * (46 * 36 * sqrt(3) / 2.0)  
  
  if (std_width / std_height > width / height){      
    scale = width / std_width    
  }    
  else{      
    scale = height / std_height    
  }    
  return(scale)
}

png = readPNG("day0.png")
zoom_scale = cal_zoom_rate(dim(png)[2], dim(png)[1])
my_table = my_table %>% mutate(across(c(x,y), ~.x*zoom_scale))

#######Epithelial cell annotation plot############
col = c("DCC" = "#70e014",
        "EEC" = "brown",
        "Goblet_0" = "#fcfc05",
        "Goblet_1" = "#00a6fb",
        "Goblet_2"  = "#FF00E6",
        "M_cell" =  "red",
        "Mid_CC" = "#a663cc",
        "PCC" = "#15821E",
        "pre_DCC" = "#ff9505",
        "pre_PCC" ="blue",
        "Stem_TA" = "#09f9f5"
)

p1 <- ggplot(my_table,aes(x = x, y = dim(png)[1]-y)) +
  background_image(png)+
  geom_point(size = 0.5, aes(color = class)) +  
  scale_color_manual(values = col)+
  coord_cartesian(xlim = c(0, dim(png)[2]), ylim = c( 0,dim(png)[1]), expand = FALSE)+
  labs(x = "x", y = "y",color = "class") +
  theme(axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank(), 
        axis.title.y=element_blank(),
        axis.text.y=element_blank(),
        axis.ticks.y=element_blank(),
        legend.key = element_blank(),
        plot.title = element_text(size = 10, hjust = 0.5, face = "bold"),  
        legend.text = element_text(size = 8),  
        legend.title = element_text(size = 8),   
        text = element_text(family = "Arial"))+
  guides(size = "none",
     color = guide_legend(override.aes = list(size = 3))) 

print(p1)

list <- 0
for (i in list){
  day <- paste0("day",i)

  ftrs <- c("Mid_CC","PCC","DCC")
  
  my_table <- my_table %>%
    mutate(color_mapping = case_when(
      class == "DCC" ~ 1,
      class == "Mid_CC" ~ 2,
      class == "PCC" ~ 3,
      TRUE ~ 0  
    ))
  
  ########DCC_MidCC_PCC ST plot#########
  p2 <- ggplot(my_table, aes(x = x, y = dim(png)[1] - y)) +
    geom_point(size = 0.1, aes(color = factor(color_mapping))) +  
    scale_color_manual(values = c("1" = "#70e014", "2" = "#a663cc", "3" = "#15821E","0" = "gray" ),
                       breaks = c("1", "2", "3", "0"),
                       labels = c("DCC", "Mid_CC", "PCC", "Others")) +
    coord_cartesian(xlim = c(0, dim(png)[2]), ylim = c(0, dim(png)[1]), expand = FALSE) +
    labs(x = "x", y = "y", color = "Class") +  
    theme(axis.title.x = element_blank(),
          axis.text.x = element_blank(),
          axis.ticks.x = element_blank(),
          axis.title.y = element_blank(),
          axis.text.y = element_blank(),
          axis.ticks.y = element_blank(),
          text = element_text(family = "Helvetica"),
          legend.background = element_blank(),  
          legend.key = element_blank(),
          legend.position = "none" )+       
    guides(color = guide_legend(override.aes = list(size = 3))) +  
    theme_void()
  
  p2
  
  #######ST plot of DCC with days#########
  p3 <- ggplot(my_table, aes(x = x, y = dim(png)[1] - y)) +
    geom_point(size = 0.1, aes(color = factor(color_mapping))) + 
    scale_color_manual(values = c("1" = "red", "2" = "gray", "3" = "gray","0" = "gray" ),
                       breaks = c("1",  "0"),
                       labels = c("DCC","Others")) +
    coord_cartesian(xlim = c(0, dim(png)[2]), ylim = c(0, dim(png)[1]), expand = FALSE) +
    labs(x = "x", y = "y", color = "Class") +  
    theme(axis.title.x = element_blank(),
          axis.text.x = element_blank(),
          axis.ticks.x = element_blank(),
          axis.title.y = element_blank(),
          axis.text.y = element_blank(),
          axis.ticks.y = element_blank(),
          text = element_text(family = "Helvetica"),
          legend.background = element_blank(),  
          legend.key = element_blank()) +      
    guides(color = guide_legend(override.aes = list(size = 3)))+  
    theme_void()
  
  p3
}