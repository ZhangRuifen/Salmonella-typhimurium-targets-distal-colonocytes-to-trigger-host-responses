library(Seurat)
library(ggplot2)
library(clusterProfiler)
library(org.Mm.eg.db)
library(dplyr)
library(tibble)
library(tidyverse)
library(ggpubr)

####cell-splited data to quantify expression of different cell types ####
object_day0 <- readRDS("d0.cell.single_seruat.Rds")
object_day1 <- readRDS("d1.cell.single_seruat.Rds")
object_day3 <- readRDS("d3.cell.single_seruat.Rds")
object_day5 <- readRDS("d5.cell.single_seruat.Rds")

object_day0 <- NormalizeData(object_day0, verbose = FALSE, assay = "Spatial")
object_day1 <- NormalizeData(object_day1, verbose = FALSE, assay = "Spatial")
object_day3 <- NormalizeData(object_day3, verbose = FALSE, assay = "Spatial")
object_day5 <- NormalizeData(object_day5, verbose = FALSE, assay = "Spatial")

combined_object <- base::merge(object_day0, y = c(object_day1, object_day3, object_day5), add.cell.ids = c("day0", "day1", "day3", "day5"))

combined_object$day <- gsub("_.*", "", colnames(combined_object))

interest_gene <- read.csv("1.KEGG_salmonella_enriched_all_ID.csv")
interest_gene <- interest_gene$Gene

sum<-NULL
day = c("day0","day1","day3","day5")
for(j in day){
  object_day<-subset(combined_object,subset = day == j)
  my_table <- readRDS(paste0(j,"_my_table_all.rds"))#result from RCTD annotation
  epithelium = c("Stem_TA","pre_DCC","pre_PCC","DCC","PCC","Mid_CC","Goblet_0","Goblet_1","Goblet_2","M_cell", "EEC")
  sub_table = my_table[my_table$class %in% epithelium, ]
  sub_table$class <- factor(sub_table$class, levels = epithelium)
  
  rownames(sub_table) <- paste0(j,"_", rownames(sub_table))
  sub_table$spot <- rownames(sub_table)
  own_gene <- rownames(object_day@assays$Spatial$data)
  gene_set2 <- Reduce(intersect,list(interest_gene,own_gene))
  
  #Addmodule scores gene sets
  gene<-as.data.frame(gene_set2)
  colnames(gene)<-'gene'
  gene <- as.list(gene)
  
  roi_means <- AddModuleScore(
    object = object_day,
    features = gene,
    ctrl = 300,
    name = 'interest_gene'
  )
  interest_gene1_data <- roi_means@meta.data$interest_gene1
  gene_names <- rownames(roi_means@meta.data)
  AddDate <- data.frame(spot = gene_names, cell_mean = interest_gene1_data)
  gene_data <- base::merge(AddDate, sub_table, by = "spot")
  
  mean_cell_expression_per_day <- gene_data %>%
    group_by(class) %>%
    summarize(mean_cell_mean = mean(cell_mean, na.rm = TRUE))  
  mean_cell_expression_per_day <- mean_cell_expression_per_day[order(mean_cell_expression_per_day$mean_cell_mean, decreasing = TRUE), ]
  
  day1_gene_expression <- gene_data
  
  gene_expression$day <- j
  
  if (j == "day0")
    gene_total_mean <- gene_expression
  else
    gene_total_mean <- rbind(gene_total_mean, gene_expression)
}

mean_cell_expression_per_day <- gene_total_mean %>%
  group_by(day, class) %>%
  summarize(mean_cell_mean = mean(cell_mean, na.rm = TRUE))  

mean_cell_expression_per_day <- mean_cell_expression_per_day[mean_cell_expression_per_day$day == "day1",]
mean_cell_expression_per_day <- mean_cell_expression_per_day[order(mean_cell_expression_per_day$mean_cell_mean, decreasing = TRUE), ]

day1_gene_expression <- gene_total_mean[gene_total_mean$day == "day1",]
write.csv(day1_gene_expression,file = "day1_gene_expression_Addmodule.csv")

day1_gene_expression$class <- factor(day1_gene_expression$class, levels = mean_cell_expression_per_day$class)
day1_gene_expression$class <- factor(day1_gene_expression$class, levels = c("pre_DCC","DCC","Goblet_0","Mid_CC","M_cell","pre_PCC","Stem_TA", "EEC","Goblet_2","Goblet_1","PCC"))

col2 = c("pre_DCC" = "#ff9505",
         "DCC" = "#70e014",
         "Goblet_0" = "#fcfc05",
         "Mid_CC" = "#a663cc",
         "M_cell" =  "red",
         "pre_PCC" ="blue",
         "Stem_TA" = "#09f9f5",
         "EEC" = "brown",
         "Goblet_2"  = "#FF00E6",
         "Goblet_1" = "#00a6fb",
         "PCC" = "#15821E")

ggplot(day1_gene_expression, aes(x = class, y = cell_mean, fill = class)) +
  geom_boxplot(width = 0.5 , outlier.shape = NA,color = col2, alpha = 0.3,size = 0.5 ) + 
  scale_fill_manual(values  = col2) +
  scale_y_continuous(limits = c(0, 0.5), breaks = c(0, 0.2,0.4)) + 
  theme_classic() +
  theme(
    legend.position="none",
    plot.title = element_text(size=10,face = "bold",hjust = 0.5),
    axis.title.x = element_text(size = 8),  
    axis.title.y = element_text(size = 8),   
    axis.text.x = element_text(size = 8,angle = 45, hjust = 1),   
    axis.text.y = element_text(size = 8)  
  ) +
  labs(title = "Day 1 Salmonella Infection Signature", y = "Average gene expression", x = "") +
stat_compare_means(method = "wilcox.test",  label = "p.signif",

                   comparisons = list(c("DCC", "pre_DCC"), c("DCC", "Goblet_0"),c("DCC", "Mid_CC"),c("DCC", "M_cell"), c("DCC", "pre_PCC"),c("DCC", "Stem_TA"),c("DCC", "EEC"),
                                      c("DCC", "Goblet_2"),c("DCC", "Goblet_1"),c("DCC", "PCC")))


