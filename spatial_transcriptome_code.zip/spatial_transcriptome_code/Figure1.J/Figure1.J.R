library(ggplot2)
library(ggsignif)
library(ggpubr)
library(gridExtra)

data1 <- read.csv(file = '1_gene_means.csv')
data1$day <- as.factor(data1$day)

color =  c("day0" = "#87CEEB", "day1" = "#F5DEB3", "day3" = "#FFD700","day5"="#20B2AA")

p1 <- ggplot(data1, aes(x = day, y = colmean, fill = day)) +
  geom_boxplot(outlier.shape = NA,alpha=0.6,color =  color) +
  theme_classic() +
  theme(
    legend.position="none",
    plot.title = element_text(size=11,face = "bold",hjust = 0.5)
  ) +
  labs(title = "Salmonella Infection Signature", y = "Average gene expression", x = "") +
  scale_fill_manual(values = color) +
  stat_compare_means(method = "wilcox.test", label = "p.signif", 
                     comparisons = list(c("day1", "day0"), c("day3", "day0"), c("day5", "day0")),
  )

print(p1)

